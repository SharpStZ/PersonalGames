global.sumn_dat_templ = {
	weak: {
		sprites: {
			attack: noone,
			damaged: noone,
			idle: noone,
		},
	
		max_hp: 1,
		curr_hp: 1,
	
		atk: 1,
		def: 1,
		spd: 1,
	
		moves: [],
		passives: [],
	},
	
	normal: {
		sprites: {
			attack: noone,
			damaged: noone,
			idle: noone,
		},
	
		max_hp: 1,
		curr_hp: 1,
	
		atk: 1,
		def: 1,
		spd: 1,
	
		moves: [],
		passives: [],
	},
	
	beefy: {
		sprites: {
			attack: noone,
			damaged: noone,
			idle: noone,
		},
	
		max_hp: 1,
		curr_hp: 1,
	
		atk: 1,
		def: 1,
		spd: 1,
	
		moves: [],
		passives: [],
	},
}

global.sumn_dat_dict = ds_map_create()

ENT_CreateSummonEntity("geode", 25, 2, 5, 2, 15, 1, 3, 1, 
[
	"slam",
	"force swap",
	"lend lifeforce"
])
ENT_CreateSummonEntity("needle", 15, 6, 1, 6, 10, 2, 1, 2, 
[
	"slam",
	"force swap",
	"lend lifeforce"
])
ENT_CreateSummonEntity("slime", 20, 4, 3, 4, 12, 2, 2, 2, 
[
	"slam",
	"force swap",
	"lend lifeforce"
])


/// @desc Returns a struct containing all forms ("Weak", "Normal", "Beefy") of a summon with adjusted stats.
/// 
/// @param {string} name       The name of the summon.
/// @param {real} hp           Base HP of the summon.
/// @param {real} atk          Base ATK of the summon.
/// @param {real} def          Base DEF of the summon.
/// @param {real} spd          Base SPD of the summon.
/// @param {real} inc_hp       Bonus HP gained per form tier (0x for Weak, 1x for Normal, 2x for Beefy).
/// @param {real} inc_atk      Bonus ATK gained per form tier.
/// @param {real} inc_def      Bonus DEF gained per form tier.
/// @param {real} inc_spd      Bonus SPD gained per form tier.
/// 
/// @return {struct}
function ENT_CreateSummonEntity(name, hp, atk, def, spd, inc_hp, inc_atk, inc_def, inc_spd, moves){
	ent_types = ["weak",  "normal",  "beefy"]
	spr_types = ["attack", "damaged", "idle"]
	
	spr_name_frag = "spr_summon_" + name
	
	ent_struct = variable_clone(global.sumn_dat_templ)
	
	
	for(i = 0; i < array_length(ent_types); i++){
		spr_name_frag2 = spr_name_frag + "_" + ent_types[i]
		
		tier_struct = variable_struct_get(ent_struct, ent_types[i]);
		
		tier_struct.max_hp	= hp  + inc_hp  * i
		tier_struct.curr_hp	= hp  + inc_hp  * i
		tier_struct.atk		= atk + inc_atk * i
		tier_struct.def		= def + inc_def * i
		tier_struct.spd		= spd + inc_spd * i
		
		tier_struct.moves   = moves
		
		for(j = 0; j < array_length(spr_types); j++){
			spr = asset_get_index(spr_name_frag2 + "_" + spr_types[j])
			//show_error(string(spr) + " " + spr_name_frag2 + "_" + spr_types[j], true)

			variable_struct_set(tier_struct.sprites, spr_types[j], spr);
		}
	}
	
	ds_map_add(global.sumn_dat_dict, name, ent_struct)
}

global.leader_dat_dict = ds_map_create()

ds_map_add(global.leader_dat_dict, "player",  {
		sprites: {
			attack: spr_summon_demon_beefy_attack,
			damaged: spr_summon_demon_beefy_damaged,
			idle: spr_summon_demon_beefy_idle,
		},
		
		ent_name: "player",
	
		max_hp: 100,
		curr_hp: 100,
	
		atk: 10,
		def: 5,
		spd: 3,
	
		moves: 
		[
			"slam"
		],
		passives: [],
})
ds_map_add(global.leader_dat_dict, "enemy",  {
		sprites: {
			attack: spr_summon_demon_beefy_attack,
			damaged: spr_summon_demon_beefy_damaged,
			idle: spr_summon_demon_beefy_idle,
		},
		
		ent_name: "enemy",
		
		max_hp: 100,
		curr_hp: 100,
	
		atk: 10,
		def: 5,
		spd: 3,
	
		moves: 
		[
			"slam"
		],
		passives: [],
})