{
  "$GMScript":"v1",
  "%Name":"Ent_EntityData",
  "isCompatibility":false,
  "isDnD":false,
  "name":"Ent_EntityData",
  "parent":{
    "name":"Entity Data",
    "path":"folders/Scripts/Entity Data.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}