function array_subtract(target_array, subtraction_array){
	
	if(is_array(subtraction_array))
	for(subtr = 0; subtr < array_length(subtraction_array); subtr++){
		if(array_contains(target_array, subtraction_array[subtr]))
			array_delete(target_array, array_get_index(target_array, subtraction_array[subtr]), 1)
	}
	else if(array_contains(target_array, subtraction_array))
		array_delete(target_array, array_get_index(target_array, subtraction_array), 1)

	return target_array
}

function array_replace(target_array, target_element, replacement, replace_all = true){
	
	index_of_replacement = -1
	
	if(replace_all)
	while(array_contains(target_array, target_element)){
		index_of_replacement = array_get_index(target_array, target_element)
		
		array_delete(target_array, index_of_replacement, 1)
		
		if(is_array(replacement)){
			for(incr = 0; incr < array_length(replacement); incr++){
				array_push(target_array, replacement[incr])
			}
		} else array_push(target_array, replacement)
	}
	
	else if(array_contains(target_array, target_element)){
		index_of_replacement = array_get_index(target_array, target_element)
		
		array_delete(target_array, index_of_replacement, 1)
		
		if(is_array(replacement)){
			for(incr = 0; incr < array_length(replacement); incr++){
				array_push(target_array, replacement[incr])
			}
		} else array_push(target_array, replacement)
	}
	
	return target_array
}

function string_upper_first(_target_string, _delimiter = " ", _remove_empty_words = true){
	_refined_string = ""
	_unrefined_strings = string_split(_target_string, _delimiter, _remove_empty_words)
	
	for (_word_index = 0; _word_index < array_length(_unrefined_strings); _word_index++){
		_refined_word = ""
		_unrefined_word = _unrefined_strings[_word_index]
		
		for(_char_index = 0; _char_index < string_length(_unrefined_word); _char_index++){
			_char = string_copy(_unrefined_word, _char_index + 1, 1)
			
			if(_char == "\\"){
				_refined_word += _char
				_char_index++
				
				if(_char_index < string_length(_unrefined_word)) 
					_refined_word += string_copy(_unrefined_word, _char_index + 1, 1)
			} 
			else if(string_letters(_char) == _char){
				_refined_word += string_upper(_char)
				_char_index++
				
				if(_char_index < string_length(_unrefined_word)) 
					_refined_word += string_copy(_unrefined_word, _char_index + 1, string_length(_unrefined_word) - _char_index)
				break
			} 
			else _refined_word += _char
		}
		
		_refined_string += string(_refined_word) + _delimiter
	}
	
	return string(_refined_string)
}