{
  "$GMScript":"v1",
  "%Name":"Opr_OperationHelpers",
  "isCompatibility":false,
  "isDnD":false,
  "name":"Opr_OperationHelpers",
  "parent":{
    "name":"Helper funcs",
    "path":"folders/Scripts/Helper funcs.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}