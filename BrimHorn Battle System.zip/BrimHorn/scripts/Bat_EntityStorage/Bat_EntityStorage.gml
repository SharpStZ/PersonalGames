global.bat_data = {
	party: {
		player: {
			slots: {
				one:	BAT_BattleSlotBaseTemplate(),
				two:	BAT_BattleSlotBaseTemplate(),
				three:	BAT_BattleSlotBaseTemplate(),
				leader: BAT_BattleSlotBaseTemplate()
			},
			
			spd: 0,
			
			energy_max: 0,
			energy_curr: 0,
			
			move_finished: false,
		},
	
		enemy: {
			slots: {
				one:	BAT_BattleSlotBaseTemplate(),
				two:	BAT_BattleSlotBaseTemplate(),
				three:	BAT_BattleSlotBaseTemplate(),
				leader: BAT_BattleSlotBaseTemplate()
			},
			spd: 0,
			
			energy_max: 0,
			energy_curr: 0,
			
			move_finished: false,
		},
		
		neutral: {
			slots: {
				one:	BAT_BattleSlotBaseTemplate(),
				two:	BAT_BattleSlotBaseTemplate(),
				three:	BAT_BattleSlotBaseTemplate()
			},
			spd: 0,
			
			energy_max: 0,
			energy_curr: 0,
			
			move_finished: false,
		},
	}
}

global.ent_pos_vars = {
	ent_box_offs_init: 20,
	ent_box_offs: 39,
	ent_stat_offs: 5,
	ent_scale: 0.75,
	
	cam_x: 240,
	cam_y: 180,
}
global.ent_pos = {
	player: {
		one: {
			coord_x: global.ent_pos_vars.ent_box_offs_init,
			coord_y: global.ent_pos_vars.cam_y / 2 - global.ent_pos_vars.ent_box_offs - global.ent_pos_vars.ent_stat_offs
		},
		two: {
			coord_x: global.ent_pos_vars.ent_box_offs_init + global.ent_pos_vars.ent_box_offs,
			coord_y: global.ent_pos_vars.cam_y / 2
		},
		three: {
			coord_x: global.ent_pos_vars.ent_box_offs_init,
			coord_y: global.ent_pos_vars.cam_y / 2 + global.ent_pos_vars.ent_box_offs + global.ent_pos_vars.ent_stat_offs
		},
		leader: {
			coord_x: global.ent_pos_vars.ent_box_offs_init,
			coord_y: global.ent_pos_vars.cam_y / 2
		}
	},
	
	enemy: {
		one: {
			coord_x: global.ent_pos_vars.cam_x - global.ent_pos_vars.ent_box_offs_init,
			coord_y: global.ent_pos_vars.cam_y / 2 - global.ent_pos_vars.ent_box_offs - global.ent_pos_vars.ent_stat_offs
		},
		two: {
			coord_x: global.ent_pos_vars.cam_x - global.ent_pos_vars.ent_box_offs_init - global.ent_pos_vars.ent_box_offs,
			coord_y: global.ent_pos_vars.cam_y / 2
		},
		three: {
			coord_x: global.ent_pos_vars.cam_x - global.ent_pos_vars.ent_box_offs_init,
			coord_y: global.ent_pos_vars.cam_y / 2 + global.ent_pos_vars.ent_box_offs + global.ent_pos_vars.ent_stat_offs
		},
		leader: {
			coord_x: global.ent_pos_vars.cam_x - global.ent_pos_vars.ent_box_offs_init,
			coord_y: global.ent_pos_vars.cam_y / 2
		}
	},
	
	neutral: {
		one: {
			coord_x: global.ent_pos_vars.cam_x / 2 - global.ent_pos_vars.ent_box_offs / 2,
			coord_y: global.ent_pos_vars.ent_box_offs_init
		},
		two: {
			coord_x: global.ent_pos_vars.cam_x / 2 + global.ent_pos_vars.ent_box_offs / 2,
			coord_y: global.ent_pos_vars.ent_box_offs_init
		},
		three: {
			coord_x: global.ent_pos_vars.cam_x / 2,
			coord_y: global.ent_pos_vars.ent_box_offs_init + global.ent_pos_vars.ent_box_offs + global.ent_pos_vars.ent_stat_offs
		}
	}
}


function BAT_BattleSlotBaseTemplate(){
	return 
	{
		//// -- Core vars -- ////
		// > Entity data vars
		ent: 0,
		ent_inst: noone,
		
		ent_name: "",
		ent_exists: false,
		
		// > Entity debuff vars
		can_move: false,
		
		//// -- Animation vars -- ////
		
		// > Summon status animation 
		status: "idle",					// Can be "idle", "damaged", "attack"
		
		// > Summon death animation
		ent_is_dead: false,
	}
}
	
function BAT_RetrieveEntityPointer(ent_party, ent_slot){
	return variable_struct_get(variable_struct_get(global.bat_data.party, ent_party).slots, ent_slot)
}