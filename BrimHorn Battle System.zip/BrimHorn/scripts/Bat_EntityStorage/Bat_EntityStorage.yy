{
  "$GMScript":"v1",
  "%Name":"Bat_EntityStorage",
  "isCompatibility":false,
  "isDnD":false,
  "name":"Bat_EntityStorage",
  "parent":{
    "name":"Entity Storage",
    "path":"folders/Scripts/Battle/Entity Storage.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}