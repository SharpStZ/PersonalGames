{
  "$GMScript":"v1",
  "%Name":"Ent_MoveData",
  "isCompatibility":false,
  "isDnD":false,
  "name":"Ent_MoveData",
  "parent":{
    "name":"Entity Data",
    "path":"folders/Scripts/Entity Data.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}