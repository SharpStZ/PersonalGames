global.ent_move_dat_dict = ds_map_create()


ds_map_add(global.ent_move_dat_dict, "slam", 
[
	"?<self ?>Pany ?>Sany ?>-self #curr_hp :-<atk",
	"?<self ?>self #curr_hp :-2",
])

ds_map_add(global.ent_move_dat_dict, "force swap", 
[
	"$! $25 ?<self ?>Pany ?>Sany ?>-self ?>S-leader #curr_hp :->curr_hp %50",
	"&! #swap"
])

ds_map_add(global.ent_move_dat_dict, "lend lifeforce", 
[
	"?<self ?>Pany ?>Sany ?>-self #curr_hp :+5",
	"?<self ?>self #curr_hp :-5",
	"?<self ?>self #max_hp :-3"
])


function ENT_EntityMoveCompile(move_script_lines, sumn_party, sumn_slot){
	actions = [] // Sequence of returnable actions stored here
	lines = move_script_lines
	action_cache = {}
	
	var file = file_text_open_append("debug_choices.txt")
	file_text_write_string(file, "[COMPILER::] Happens!\n")
	
	for(i = 0; i < array_length(lines); i++){
		line = string_trim(lines[i])
		if(line == "") continue;
		
		nodes = string_split(line, " ")
		action = ENT_EntityMoveCreateEmptyAction()
		
		// The middleman will ALWAYS contain position data of the movemaker.
		// It shouldn't be changed, or bugs may arise.
		
		// This position will update troughout the moves to maintain position when the
		// movemaker decides to switch its position elsewhere.
		action.middleman.slot = sumn_slot
		action.middleman.party = sumn_party
		
		possible_stat_types = [
			"max_hp", "curr_hp", "atk", "def", "spd",	// Direct stats
		]
		
		possible_pos_types = [
			"swap", "give", "steal"						// Positional stats
		]
		
		for(j = 0; j < array_length(nodes); j++){
			node = string_trim(nodes[j])
			if(node == "") continue;
			
			identificator = string_copy(node, 1, 1)
			node = string_delete(node, 1, 1)
			
			switch identificator {
				// Checks whether this action is chaining the last one's choices
				case "&":
					if(node == "!"){
						action.is_exec_linked = true
					}
				
					//action = variable_clone(action_cache)
					action.is_chaining = true
					
					
					// These track whether the party and / or target's slot and / or party had changed.
					// If each don't change during chaining, the action copies previous action's pointer for em.
					action.target.party_had_changed = false
					action.target.slot_had_changed = false
					action.target.spec_had_changed = false
					
					action.attacker.party_had_changed = false
					action.attacker.slot_had_changed = false
					action.attacker.spec_had_changed = false
					
					action.amount = 0
				break;
				
				
				// Checks for a CHANCE type variable
				case "$":
					if(node == "!"){
						action.chance_tied_to_exec = true
					}
					else if(array_contains(possible_stat_types, string_delete(node, 0, 1))) 
						action.chance = node				// STAT variable
					else if(string(real(node)) == node or "+" + string(real(node)) == node) 
						action.chance = real(node)			// Constant variable 
					else {
						show_error("ERR! '$' Type variable in node '" + nodes[j] + "' has an invalid CHANCE: '" + node + "';", false)
						show_error("CHANCE must be a real number or a pointer, followed by STAT: 'max_hp', 'curr_hp', 'atk', 'def', 'spd'", true)
					}
				break;
				
				
				// Checks for CHOICE type variables
				case "!":
					if(node == ""){
						show_error("ERR! '!' Type variable in node '" + nodes[j] + "' has no 2ND identificator;", false)
						show_error("2ND identificators must be either '?' or '!'", true)
					}
					else if(node == "?")
						action.can_skip = true
					else if(node == "!")
						action.can_skip = false
					else {
						show_error("ERR! '!' Type variable in node '" + nodes[j] + "' has an invalid 2ND identificator: '" + node + "';", false)
						show_error("2ND identificators must be either '?' or '!'", true)
					}
					
				break;
				
				
				// Checks for WHICH type variables
				case "?":
					identificator2 = string_copy(node, 1, 1)
					node = string_delete(node, 0, 1)
					
					who = ""
					which = ""
					
					switch identificator2 {
						case ">":
							who = "target"
						break;
						case "<":
							who = "attacker"
						break;
						default:
							show_error("ERR! '?' Type variable in node '" + nodes[j] + "' has an invalid 2ND identificator: '" + identificator2 + "';", false)
							show_error("2ND identificators must be either '>' or '<'", true)
						break;
					}
					
					identificator3 = string_copy(node, 1, 1)
					node = string_delete(node, 0, 1)
					
					ptr_is_subtraction = false
					
					if(identificator3 == "-"){
						ptr_is_subtraction = true
						
						identificator3 = string_copy(node, 1, 1)
						node = string_delete(node, 0, 1)
					}
					
					switch identificator3 {
						case "P":
							which = "party"
						break;
						case "S":
							which = "slot"
						break;
						
						default:
							which = "both"
							
							pointers = string_split(identificator3 + node, "_")
							
							loc_str = {
								party: pointers[0],
								slot: pointers[0]
							}
							if(array_length(pointers) > 1) loc_str.ptr_slot = pointers[1] 
							
							if(!ptr_is_subtraction) array_push(variable_struct_get(action, who).spec, loc_str)
							else if (ptr_is_subtraction) array_push(variable_struct_get(action, who).spec_excl, loc_str)
							
							file_text_write_string(file, "[COMPILER::] Added '" + loc_str.party + "_" + loc_str.slot + "' to " + who + "'s " + "specific exclusions!\n")
						break;
					}
					
					if(string_copy(node, 0, 1) == "-"){
						ptr_is_subtraction = true
						
						node = string_delete(node, 0, 1)
					}
					
					// Marks which pointer had changed for chaining purposes.
					// Unchanged pointers ALWAYS copy previous action's pointers
					if(action.is_chaining) switch who {
						case "target":
							switch which {
								case "party":
									action.target.party_had_changed = true
								break;
								case "slot":
									action.target.slot_had_changed = true
								break;
								case "both":
									action.target.party_had_changed = true
									action.target.slot_had_changed = true
								break;
							}
						break;
						case "attacker":
							switch which {
								case "party":
									action.attacker.party_had_changed = true
								break;
								case "slot":
									action.attacker.slot_had_changed = true
								break;
								case "both":
									action.target.party_had_changed = true
									action.target.slot_had_changed = true
								break;
							}
						break;
					}
					
					all_party = ["player", "enemy", "neutral"]
					all_slot = ["one", "two", "three", "leader"]
					
					if(which != "both" and !ptr_is_subtraction) {
						if(node == "all"){
							switch which {
								case "party":
									for(k = 0; k < array_length(all_party); k++){
										if(!array_contains(variable_struct_get(action, who).party, all_party[k]))
											array_push(variable_struct_get(action, who).party, all_party[k])
									}
								break
								case "slot":
									for(k = 0; k < array_length(all_slot); k++){
										if(!array_contains(variable_struct_get(action, who).slot, all_slot[k]))
											array_push(variable_struct_get(action, who).slot, all_slot[k])
									}
								break
							}
						}
						else array_push(variable_struct_get(variable_struct_get(action, who), which), node)
						
						file_text_write_string(file, "[COMPILER::] Added '" + node + "' to " + who + "'s " + which + "!\n")
					}
					
					else if(which != "both" and ptr_is_subtraction) {
						if(node == "all"){
							switch which {
								case "party":
									for(k = 0; k < array_length(all_party); k++){
										if(!array_contains(variable_struct_get(action, who).party_excl, all_party[k]))
											array_push(variable_struct_get(action, who).party_excl, all_party[k])
									}
								break
								case "slot":
									for(k = 0; k < array_length(all_slot); k++){
										if(!array_contains(variable_struct_get(action, who).slot_excl, all_slot[k]))
											array_push(variable_struct_get(action, who).slot_excl, all_slot[k])
									}
								break
							}
						}
						else array_push(variable_struct_get(variable_struct_get(action, who), which + "_excl"), node)
						
						file_text_write_string(file, "[COMPILER::] Added '" + node + "' to " + who + "'s " + which + " exclusions!\n")
					}
					
				break;
				
				
				// Checks for STAT type variables
				case "#":
					if(array_contains(possible_stat_types, node) or array_contains(possible_pos_types, node)) action.act_type = node
					else {
						show_error("ERR! '#' Type variable in node '" + nodes[j] + "' has an invalid STAT: '" + node + "';", false)
						show_error("STATS must be 'max_hp', 'curr_hp', 'atk', 'def', 'spd', 'swap', 'give', 'steal'", true)
					}
				break;
				
				
				// Checks for AMOUNT_PERC type variables
				case "%":
					if(array_contains(possible_stat_types, string_delete(node, 0, 1))) 
						action.amount_percent = node			// STAT variable
					else if(string(real(node)) == node or "+" + string(real(node)) == node) 
						action.amount_percent = real(node)		// Constant variable 
					else {
						show_error("ERR! '%' Type variable in node '" + nodes[j] + "' has an invalid AMOUNT_PERC: '" + node + "';", false)
						show_error("AMOUNT_PERC must be a real number or a pointer, followed by STAT: 'max_hp', 'curr_hp', 'atk', 'def', 'spd'", true)
					}
				break;
				
				
				// Checks for AMOUNT type variables
				case ":":
					
				
					identificator2 = string_copy(node, 1, 1)
					node = string_delete(node, 0, 1)
					
					identificator3 = string_copy(node, 1, 1)
					
					// If it's followed by a pointer, it takes a stat variable as the modifier
					if(identificator3 == ">" or identificator3 == "<" or identificator3 == "^") {
						if(array_contains(possible_stat_types, string_delete(node, 0, 1))) action.amount = identificator2 + node
						else {
							show_error("ERR! ':' Type variable in node '" + nodes[j] + "' has an invalid AMOUNT: '" + node + "';", false)
							show_error("AMOUNT must be only a real value, or '>', '<', '^' followed by a direct STAT (such as 'curr_hp', 'atk')", true)
						}
					}
					
					// If it's NOT followed by a pointer, it takes a flat value as the modifier
					else {
						action.amount = string(identificator2) + string(node)
					}
					
				break;
			}
		}
		
		if(action.act_type == ""){
			show_error("ERR! Action's  act_type variable is empty! It must be set via '#';", true)
		}
		
		array_push(actions, action)
		action_cache = variable_clone(action)
	}
	
	file_text_close(file)
	
	return actions
}

function ENT_EntityMoveExtractEntitiesBattle(action, who) {
	
	
	
	var file = file_text_open_append("debug_choices.txt")
	
	file_text_write_string(file, "\n")
	file_text_write_string(file, "[BAT-EXTR::] Happens!\n")
	file_text_write_string(file, "[BAT-EXTR::] Currently extracting " + who + "s...\n")
	file_text_write_string(file, "[BAT-EXTR::] Initial data:\n")
	
	file_text_write_string(file, "[BAT-EXTR::] > " + who + "'s parties:\n")
	for(i = 0; i < array_length(variable_struct_get(action, who).party); i++){
		party = variable_struct_get(action, who).party[i]
		file_text_write_string(file, "[BAT-EXTR::]   > " + party + "\n")
	}
	
	file_text_write_string(file, "[BAT-EXTR::] > " + who + "'s slots:\n")
	for(i = 0; i < array_length(variable_struct_get(action, who).slot); i++){
		slot = variable_struct_get(action, who).slot[i]
		file_text_write_string(file, "[BAT-EXTR::]   > " + slot + "\n")
	}
	
	file_text_close(file)
	file = file_text_open_append("debug_choices.txt")

	entities = []
	
	extracted_party = variable_clone(variable_struct_get(action, who).party)
	extracted_slot  = variable_clone(variable_struct_get(action, who).slot)
	extracted_spec	= variable_clone(variable_struct_get(action, who).spec)
	
	party_excl		= variable_clone(variable_struct_get(action, who).party_excl)
	slot_excl		= variable_clone(variable_struct_get(action, who).slot_excl)
	spec_excl		= variable_clone(variable_struct_get(action, who).spec_excl)
	
	// Filter out parties and slots
	for(i = 0; i < array_length(party_excl);		i++){
		if(array_contains(extracted_party, party_excl[i])){
			array_delete(extracted_party, array_get_index(extracted_party, party_excl[i]), 1)
		}
	}
	for(i = 0; i < array_length(slot_excl);			i++){
		if(array_contains(extracted_slot, slot_excl[i])){
			array_delete(extracted_slot, array_get_index(extracted_slot, slot_excl[i]), 1)
		}
	}

	
	// Generate valid combinations of entities
	for(i = 0; i < array_length(extracted_party);	i++){
		for(j = 0; j < array_length(extracted_slot); j++){
			array_push(entities, {
				party: extracted_party[i],
				slot: extracted_slot[j]
			})
		}
	}
	for(i = 0; i < array_length(extracted_spec);	i++){
		if(!array_contains(entities, {
			party: extracted_spec[i].party,
			slot: extracted_spec[i].slot,
		}))
		array_push(entities, {
			party: extracted_spec[i].party,
			slot: extracted_spec[i].slot,
		})
	}
	
	// Exclude specified entities
	for(i = 0; i < array_length(spec_excl);			i++){
		if(array_contains(entities, {
			party: spec_excl[i].party,
			slot: spec_excl[i].slot,
		}))
		array_delete(entities, array_get_index(entities, {
			party: spec_excl[i].party,
			slot: spec_excl[i].slot,
		}), 1)
	}
		
	file_text_write_string(file, "[BAT-EXTR::] Ends! Extracted " + string(array_length(entities)) + " entities!\n")
	file_text_close(file)
	
	return entities;
}

function ENT_EntityMoveExtractEntitiesChoice(action, who){
	var file = file_text_open_append("debug_choices.txt")
	
	file_text_write_string(file, "\n")
	file_text_write_string(file, "[CHC_EXTR::] Happens!\n")
	
	file_text_close(file)
	file = file_text_open_append("debug_choices.txt")
	
	choices = {
		party: [],
		slot: [],
		
		can_choose_party: false,
		can_choose_slot: false
	}
	
	aval_parties = 0
		
	aval_spec = 0
	excl_spec = 0
		
	aval_slots = ds_map_create()
	
	if(who == "target"){
		aval_parties = variable_clone(action.target.party)
		if(array_contains(action.target.party, "any")) {
			aval_parties = ["player", "enemy", "neutral"]
			choices.can_choose_party = true
		}

		aval_parties = array_subtract(aval_parties, action.target.party_excl)

		aval_spec = variable_clone(action.target.spec)
		excl_spec = variable_clone(action.target.spec_excl)

		for(i = 0; i < array_length(aval_parties); i++){
			if(array_contains(action.target.slot, "any")){
				aval_slots_one = ["one", "two", "three", "leader"]
				choices.can_choose_slot = true
			}
			else aval_slots_one = variable_clone(action.target.slot)

			aval_slots_one = array_subtract(aval_slots_one, action.target.slot_excl)
		
			ds_map_add(aval_slots, variable_clone(aval_parties[i]), aval_slots_one)
		}
	}
	if(who == "attacker"){
		aval_parties = variable_clone(action.attacker.party)
		if(array_contains(action.attacker.party, "any")) {
			aval_parties = ["player", "enemy", "neutral"]
			choices.can_choose_party = true
		}
		
		aval_parties = array_subtract(aval_parties, action.attacker.party_excl)
		
		aval_spec = variable_clone(action.attacker.spec)
		excl_spec = variable_clone(action.attacker.spec_excl)
		
		for(i = 0; i < array_length(aval_parties); i++){
			if(array_contains(action.attacker.slot, "any")){
				aval_slots_one = ["one", "two", "three", "leader"]
				choices.can_choose_slot = true
			}
			else aval_slots_one = variable_clone(action.attacker.slot)
		
			aval_slots_one = array_subtract(aval_slots_one, action.attacker.slot_excl)
		
			ds_map_add(aval_slots, aval_parties[i], aval_slots_one)
		}
	}
	
	
	for(i = 0; i < array_length(aval_spec); i++){
		if(!array_contains(aval_parties, aval_spec[i].party)){
			array_push(aval_parties, aval_spec[i].party)
			
			ds_map_add(aval_slots, aval_spec[i].party, [aval_spec[i].slot])
		}
		else if(!array_contains(aval_slots[?aval_spec[i].party], aval_spec[i].slot))
			array_push(aval_slots[?aval_spec[i].party], aval_spec[i].slot)
	}
	for(i = 0; i < array_length(excl_spec); i++){
		if(array_contains(aval_parties, excl_spec[i].party)){
			if(array_contains(aval_slots[?excl_spec[i].party], excl_spec[i].slot)){
				array_delete(aval_slots[?excl_spec[i].party], array_get_index(aval_slots[?excl_spec[i].party], excl_spec[i].slot), 1)
				
				if(array_length(aval_slots[?excl_spec[i].party]) == 0){
					array_subtract(aval_parties, excl_spec[i].party)
					ds_map_delete(aval_slots, excl_spec[i].party)
				}
			}
		}
	}
	
	choices.party = variable_clone(aval_parties)
	choices.slot = variable_clone(aval_slots)
	
	file_text_write_string(file, "[CHC_EXTR::] Stats after refinery:\n")
	
	file_text_write_string(file, "[CHC_EXTR::] " + who + "'s parties:\n")
	for(i = 0; i < array_length(choices.party); i++){
		one_party = choices.party[i]
		file_text_write_string(file, "[CHC_EXTR::] " + "> " + one_party + ":\n")
		for(j = 0; j < array_length(choices.slot[?one_party]); j++){
			one_slot = choices.slot[?one_party][j]
			file_text_write_string(file, "[CHC_EXTR::] " + "  > " + one_slot + "\n")
		}
	}
	
	file_text_close(file)
	
	return choices
}

function ENT_EntityMoveRefine(action, last_action = false){
	
	var file = file_text_open_append("debug_choices.txt")
	
	file_text_write_string(file, "\n")
	file_text_write_string(file, "[REFINERY::] Happens!\n")
	
	// If the action is skipped or has an unlucky roll, it will not be executed.
	// No further refinement needed, it's a dud.
	if(!action.can_be_executed) {
		array_push(action.statuses, "Action is un-executable.") 
		return action
	}
	
	// The last action won't always exist, therefore it will be set for the first action refining as false.
	if(last_action != false){
		// If the middleman had changed, it will change in the next actions as well.
		// This is done to avoid glitchy behavior when swapping the middleman by proxy,
		// and is the main purpose why the middleman party exists.
		action.middleman.party  = last_action.middleman.party
		action.middleman.slot   = last_action.middleman.slot
		
		
		// If the action is chaining the last one, it will copy the last action's decisions.
		// This is to prevent allowing the player to choose targets / attackers again if unintended.
		// Might seem like weird logic, but i feel like it may add uniqueness to attacks!
		if(action.is_chaining){
			file_text_write_string(file, "[REFINERY::] Chaining inheritance '&' happens!\n")
			
			if(!action.target.party_had_changed){
				action.target.party = variable_clone(last_action.target.party)
				action.target.party_excl = variable_clone(last_action.target.party_excl)
			}
			if(!action.target.slot_had_changed){
				action.target.slot = variable_clone(last_action.target.slot)
				action.target.slot_excl = variable_clone(last_action.target.slot_excl)
			}
			if(!action.target.spec_had_changed){
				action.target.spec = variable_clone(last_action.target.spec)
				action.target.spec_excl = variable_clone(last_action.target.spec_excl)
			}
			
			if(!action.attacker.party_had_changed){
				action.attacker.party = variable_clone(last_action.attacker.party)
				action.attacker.party_excl = variable_clone(last_action.attacker.party_excl)
			}
			if(!action.attacker.slot_had_changed){
				action.attacker.slot = variable_clone(last_action.attacker.slot)
				action.attacker.slot_excl = variable_clone(last_action.attacker.slot_excl)
			}
			if(!action.attacker.spec_had_changed){
				action.attacker.spec = variable_clone(last_action.attacker.spec)
				action.attacker.spec_excl = variable_clone(last_action.attacker.spec_excl)
			}
			
			
			// If the first action is skipped or had a bad roll, the chaining action will
			// also be unexecutable. That's the purpose of chaining!
			// This can be reverted via using & instead of && when chaining
			if(action.is_exec_linked) action.can_be_executed = last_action.can_be_executed
			if(!action.can_be_executed) {
				array_push(action.statuses, "Action is un-executable.") 
				return action
			}
		}
	}
	

	// "self" meaning it's referring to the middleman, the move executor.
	// These "self" pointers get changed to middleman real-time, as the middleman's
	// position can change, therefore this cannot be done on direct compile.

	function replace_self_in_array(arr, middle_value) {
		for (var i = 0; i < array_length(arr); i++) {
			if (arr[i] == "self") arr[i] = middle_value;
		}
	}	

	function replace_self_in_spec_array(spec_arr, middle_party, middle_slot) {
		for (var i = 0; i < array_length(spec_arr); i++) {
			if (spec_arr[i].party == "self") spec_arr[i].party = middle_party;
			if (spec_arr[i].slot  == "self") spec_arr[i].slot  = middle_slot;
		}
	}
	
	var	mid = action.middleman;
	
	// Apply to target
	replace_self_in_array(action.target.party,       mid.party);
	replace_self_in_array(action.target.party_excl,  mid.party);
	replace_self_in_array(action.target.slot,        mid.slot);
	replace_self_in_array(action.target.slot_excl,   mid.slot);
	replace_self_in_spec_array(action.target.spec,       mid.party, mid.slot);
	replace_self_in_spec_array(action.target.spec_excl,  mid.party, mid.slot);
	
	// Apply to attacker
	replace_self_in_array(action.attacker.party,       mid.party);
	replace_self_in_array(action.attacker.party_excl,  mid.party);
	replace_self_in_array(action.attacker.slot,        mid.slot);
	replace_self_in_array(action.attacker.slot_excl,   mid.slot);
	replace_self_in_spec_array(action.attacker.spec,       mid.party, mid.slot);
	replace_self_in_spec_array(action.attacker.spec_excl,  mid.party, mid.slot);
	
	
	file_text_write_string(file, "[REFINERY::] Stats after refinery:\n")
	
	file_text_write_string(file, "[REFINERY::] Attacker's parties:\n")
	for(i = 0; i < array_length(action.attacker.party); i++)
		file_text_write_string(file, "[REFINERY::] > " + action.attacker.party[i] + "\n")
		
	file_text_write_string(file, "[REFINERY::] Attacker's slots:\n")
	for(i = 0; i < array_length(action.attacker.slot); i++)
		file_text_write_string(file, "[REFINERY::] > " + action.attacker.slot[i] + "\n")
		
	file_text_write_string(file, "[REFINERY::] Target's parties:\n")
	for(i = 0; i < array_length(action.target.party); i++)
		file_text_write_string(file, "[REFINERY::] > " + action.target.party[i] + "\n")
		
	file_text_write_string(file, "[REFINERY::] Target's slots:\n")
	for(i = 0; i < array_length(action.target.slot); i++)
		file_text_write_string(file, "[REFINERY::] > " + action.target.slot[i] + "\n")
	
	file_text_close(file)
	
	return action
}

function ENT_EntityMoveExecuteStep(action, one_attacker, one_target, the_middleman){
	
	var file = file_text_open_append("debug_choices.txt")
	file_text_write_string(file, "\n")
	file_text_write_string(file, "[ENT-MOV-EXEC-STP::] Happens!\n")
	
	file_text_write_string(file, "[ENT-MOV-EXEC-STP::] " + 
		one_attacker.party + "_" + one_attacker.slot + 
		" Is attacking " +
		one_target.party + "_" + one_target.slot + 
	"\n")
	
	
	if( !BAT_EntityInstanceExists(one_attacker.party,	one_attacker.slot)	or 
		!BAT_EntityInstanceExists(one_target.party,		one_target.slot)	or 
		!BAT_EntityInstanceExists(the_middleman.party,	the_middleman.slot)) {
		action.can_be_executed = false
		return action
	}
	
	targ_pos = one_target
	attk_pos = one_attacker
	
	// If the action is a stat change, the action.amount is flattened to a constant 
	vars_stat = ["max_hp", "curr_hp", "atk", "def", "spd"]
	vars_pos =  ["steal", "give", "swap"]
	
	// Targeted slot
	var target = variable_struct_get(
		variable_struct_get(global.bat_data.party, one_target.party).slots, 
	one_target.slot)
	
	// Targeted party
	var target_slots = variable_struct_get(global.bat_data.party, one_target.party).slots
		
	// Attacker slot
	var attacker = variable_struct_get(
		variable_struct_get(global.bat_data.party, one_attacker.party).slots, 
	one_attacker.slot)
	
	// Attacker party
	var attacker_slots = variable_struct_get(global.bat_data.party, one_attacker.party).slots
	
	// Middleman slot
	var middleman = variable_struct_get(
		variable_struct_get(global.bat_data.party, the_middleman.party).slots, 
	one_attacker.slot)
	
	// Middleman party
	var middleman_slots = variable_struct_get(global.bat_data.party, the_middleman.party).slots
	
	// Current slot
	var slot = "none"
	
	var middleman_is_target = 
		(one_target.party == action.middleman.party and one_target.slot == action.middleman.slot)
	var middleman_is_attacker = 
		(one_attacker.party == action.middleman.party and one_attacker.slot == action.middleman.slot)
	
	// First flattens chance into a constant if it's a variable
	if(is_string(action.chance)) {
		var who_chance = ""
		stat = string_delete(action.chance, 0, 1)
		
		switch string_copy(action.chance, 0, 1) {
			case ">":
				action.chance = variable_struct_get(target.ent, stat)
			break;
			case "<":
				action.chance = variable_struct_get(attacker.ent, stat)
			break;
			case "^":
				action.chance = variable_struct_get(middleman.ent, stat)
			break;
		}
	}

	
	// If the chance is tied to execution, it will make the action unexecutable too.
	// Great when making attacks which can proc multiple times until it rolls a bad chance
	
	if(!action.is_chaining or !action.is_exec_linked){
		// Rolls whether this action can be performed in the first place
		// If not, stops the action
		
		randomize()
		if(irandom(100) > action.chance) {
			if(action.chance_tied_to_exec) action.can_be_executed = false
			
			array_push(action.statuses, "Action failed! Bad chance roll!")
			file_text_close(file)
			return action
		}
	}
	
	
	
	if(array_contains(vars_pos, action.act_type)) switch action.act_type {
		case "steal":
			
			// Does target exist? If not, continues to other entities.
			if(!target.ent_exists) {
				array_push(action.statuses, "Action failed! Target doesn't exist.")
				file_text_close(file)
				return action
			}
			// Searches for a free slot in the attacker's party
			slot = ENT_EntityMoveReturnFreeSpace(one_attacker.party)
			if(slot == "none") {
				array_push(action.statuses, "Action failed! No slot available in attacker's party.")
				file_text_close(file)
				return action
			}
			
			// Middleman conserves it's position across actions, even when moved
			if(middleman_is_target){
				action.middleman.party = one_attacker.party
				action.middleman.slot = slot
			}
			
			
			// Puts selected target into the attacker's party
			variable_struct_set(attacker_slots, slot, variable_clone(target))
			
			// Resets stolen target's slot
			variable_struct_set(target_slots, one_target.slot, BAT_BattleSlotBaseTemplate())
			
			// Updates entity positions
			target.ent_inst.LOC_UpdateEntityPosition(one_attacker.party, one_attacker.slot)
			
			array_push(action.statuses, "Success! Target was moved to attacker's party!")
		break;
		
		case "give":
		
			// Does attacker exist? If not, continues to other entities.
			if(!attacker.ent_exists) {
				array_push(action.statuses, "Action failed! Attacker doesn't exist.")
				file_text_close(file)
				return action
			}
			// Searches for a free slot in the target's party
			slot = ENT_EntityMoveReturnFreeSpace(one_target.party)
			if(slot == "none") {
				array_push(action.statuses, "Action failed! No slot available in target's party.")
				file_text_close(file)
				return action
			}
			
			// Middleman conserves it's position across actions, even when moved
			if(middleman_is_target){
				action.middleman.party = one_attacker.party
				action.middleman.slot = slot
			}
			
			
			// Puts selected attacker into the target's party
			variable_struct_set(target_slots, slot, variable_clone(attacker))
			
			// Resets given attacker's slot
			variable_struct_set(attacker_slots, one_attacker.slot, BAT_BattleSlotBaseTemplate())
			
			// Updates entity positions
			attacker.ent_inst.LOC_UpdateEntityPosition(one_target.party, one_target.slot)
			
			array_push(action.statuses, "Success! Attacker was moved to target's party!")
		break;
		
		case "swap":
				
			// Does target exist? If not, continues to other entities.
			if(!target.ent_exists) {
				array_push(action.statuses, "Action failed! Target doesn't exist.")
				file_text_close(file)
				return action
			}
			// Does target exist? If not, continues to other entities.
			if(!attacker.ent_exists) {
				array_push(action.statuses, "Action failed! Attacker doesn't exist.")
				file_text_close(file)
				return action
			}

	
			// Stores attacker in cache for swap
			var attacker_cache = variable_clone(attacker)
			
			// Swaps target and attacker
			variable_struct_set(attacker_slots, one_attacker.slot, variable_clone(target))
			variable_struct_set(target_slots, one_target.slot, variable_clone(attacker_cache))
			
			// Updates entity positions
			target.ent_inst.LOC_UpdateEntityPosition(one_attacker.party, one_attacker.slot)
			attacker.ent_inst.LOC_UpdateEntityPosition(one_target.party, one_target.slot)
			
			array_push(action.statuses, "Success! Target's and attacker's positions were swapped!")
		break;
		
		default:
			show_error("ERR! an action within ENT_EntityMoveExecuteStep has an invalid act_type.", true)
		break;
	}
	else if (array_contains(vars_stat, action.act_type)){
		
		var opr_amount = 0
		
		file_text_write_string(file, "[ENT-MOV-EXEC-STP::] Modified stat is: " + action.act_type + "\n")
		file_text_write_string(file, "[ENT-MOV-EXEC-STP::] Modified stat amount is: " + string(action.amount) + "\n")
		
		file_text_write_string(file, "[ENT-MOV-EXEC-STP::] opr_amount before is: " + string(opr_amount) + "\n")
		
		opr = string_copy(action.amount, 1, 1)
		amount_is_real = true
		
		try {
			real(string_delete(action.amount, 1, 1))
		} catch (err) {
			amount_is_real = false
		}
			
		
		if(!amount_is_real){
			
			// Example: action.amount = "+>atk" (adds attacker's ATK to target's stat)
			stat = string_delete(action.amount, 1, 2)
			
			file_text_write_string(file, "[ENT-MOV-EXEC-STP::] stat before is: " + string(stat) + "\n")
			
			file_text_close(file)
			file = file_text_open_append("debug_choices.txt")
			
			switch string_copy(action.amount, 2, 1) {
				case ">":
					opr_amount = variable_struct_get(target.ent, stat)
				break;
				case "<":
					opr_amount = variable_struct_get(attacker.ent, stat)
				break;
				case "^":
					opr_amount = variable_struct_get(middleman.ent, stat)
				break;
			}
			
			// If percentage stat is not constant, flattens the referrenced stat value to a constant
			if(is_string(action.amount_percent)){
				stat = string_delete(action.amount_percent, 0, 1)
				
				switch string_copy(action.amount_percent, 1, 1) {
					case ">":
						action.amount_percent = variable_struct_get(target.ent, stat)
					break;
					case "<":
						action.amount_percent = variable_struct_get(attacker.ent, stat)
					break;
					case "^":
						action.amount_percent = variable_struct_get(middleman.ent, stat)
					break;
				}
			}
		} 
		else {
			//if(action.amount == "+5")
			//	show_error(
			//		one_attacker.party + "_" + one_attacker.slot + 
			//		" Is healing " +
			//		one_target.party + "_" + one_target.slot, 
			//		true
			//	)
			
			opr_amount = real(string_delete(action.amount, 1, 1))
		}
		opr_amount = round(opr_amount * action.amount_percent / 10) / 10

				
		//show_error("SLAM HAPPENS! " + opr + " " + string(opr_amount),	true)
		
		switch opr {
			case "+":
				opr_amount = variable_struct_get(target.ent, action.act_type) + opr_amount
			break;
			case "-":
				opr_amount = variable_struct_get(target.ent, action.act_type) - opr_amount
			break;
			case "*":
				opr_amount = variable_struct_get(target.ent, action.act_type) * opr_amount
			break;
			case "/":
				opr_amount = variable_struct_get(target.ent, action.act_type) / opr_amount
			break;
		}
		
		file_text_write_string(file, "[ENT-MOV-EXEC-STP::] Final value of target [" + one_target.party + "_" + one_target.slot + "] is" + string(opr_amount) + "\n")
		
		variable_struct_set(target.ent, action.act_type, opr_amount)
			
		if(action.act_type == "max_hp" or action.act_type == "curr_hp"){
			var curr_hp = variable_struct_get(target.ent, "curr_hp")
			var max_hp = variable_struct_get(target.ent, "max_hp")
			
			if(curr_hp <= 0 or max_hp <= 0) {
				variable_struct_set(target, "ent_is_dead", true)
				array_push(action.statuses, "Success! Target's stat [" + action.act_type + "] was modified! TARGET KILLED")
				target.ent_exists = false
				
				target.ent.curr_hp = 0
			}
			else {
				array_push(action.statuses, "Success! Target's stat [" + action.act_type + "] was modified! TARGET ALIVE")
				
				if(curr_hp > max_hp) 
					variable_struct_set(target.ent, "curr_hp", max_hp)
			}
		}
		
		target.ent_inst.LOC_UpdateEntityStats()
	}
	
	file_text_close(file)
	
	return action 
}

function ENT_EntityMoveReturnFreeSpace(party){
	slot_str = variable_struct_get(global.bat_data.party, party).slots
	
	if(slot_str.one.ent   == 0) return "one"
	if(slot_str.two.ent	  == 0)	return "two"
	if(slot_str.three.ent == 0) return "three"
	
	return "none"
}



function ENT_EntityMoveCreateEmptyAction(){
	return {
		
		// Pointer vars
		target: {
			party: array_create(0, 0),
			party_excl: array_create(0, 0),
			
			slot: array_create(0, 0),
			slot_excl: array_create(0, 0),
			
			spec: array_create(0, 0),
			spec_excl: [{
				party: "neutral",
				slot: "leader"
			}],
			
			party_had_changed: false,
			slot_had_changed: false,
			spec_had_changed: false,
		},
		
		attacker: {
			party: array_create(0, 0),
			party_excl: array_create(0, 0),
			
			slot: array_create(0, 0),
			slot_excl: array_create(0, 0),
			
			spec: array_create(0, 0),
			spec_excl: [{
				party: "neutral",
				slot: "leader"
			}],
			
			party_had_changed: false,
			slot_had_changed: false,
			spec_had_changed: false,
		},
		
		middleman: {
			party: "",
			slot: "",
		},
		
		// Core vars
		act_type: "",
		
		amount: 0,
		amount_percent: 100,
		
		// Chaining vars
		is_chaining: false,
		is_exec_linked: false,
		
		// Execution vars
		chance: 100,
		chance_tied_to_exec: false,
		
		can_skip: false,
		can_be_executed: true,
		
		// Status cache for on-screen debugging
		statuses: []
	}
}