// Movement, collision and animation updating
if(mobility){
	// Old variable trackers
	movement.old_moving = movement.is_moving
	movement.old_facing = movement.is_facing
	
	// Checks for movement 
	movement.spd_x = (keyboard_check(vk_right) - keyboard_check(vk_left)) * movement.spd_mult
	movement.spd_y = (keyboard_check(vk_down)  - keyboard_check(vk_up))   * movement.spd_mult
	
	// Movement normalization
	if(movement.spd_x != 0 and movement.spd_y != 0){
		movement.spd_x *= sqrt(2) / 2
		movement.spd_y *= sqrt(2) / 2
	}
	
	// Coordinate updating and collision checking
	movement.is_moving = false
	if(movement.spd_x != 0 and place_free(x + movement.spd_x, y)){
		x += movement.spd_x
		movement.is_moving = true
	}
	if(movement.spd_y != 0 and place_free(x, y + movement.spd_y)){
		y += movement.spd_y
		movement.is_moving = true
	}
	
	// Facing direction updating
	if(movement.is_moving){
		if     (movement.spd_y < 0)
			movement.is_facing = "up"
		else if(movement.spd_y > 0)
			movement.is_facing = "down"
		else if(movement.spd_x < 0)
			movement.is_facing = "left"
		else if(movement.spd_x > 0)
			movement.is_facing = "right"
	}
	
	// Animation updating
	if(movement.old_moving != movement.is_moving or movement.old_facing != movement.is_facing){
		switch movement.is_facing {
			case "up":
				if(movement.is_moving)	sprite_index = spr_player_up
				else					sprite_index = spr_player_up2
			break;
			case "down":
				if(movement.is_moving)	sprite_index = spr_player_down
				else					sprite_index = spr_player_down2
			break;
			case "left":
				if(movement.is_moving)	sprite_index = spr_player_left
				else					sprite_index = spr_player_left2
			break;
			case "right":
				if(movement.is_moving)	sprite_index = spr_player_right
				else					sprite_index = spr_player_right2
			break;
		}
	}
}