mobility = true

movement = {
	is_moving: false,
	is_facing: "down",
	
	old_moving: false,
	old_facing: "up",
	
	spd_mult: 1.15,
	spd_x: 0,
	spd_y: 0,
}