/// @description Use this to reset entity bobbing, sprites, etc.
if(entity_ptr.ent_exists){
	animation_vars.bobbing_anim.spd = animation_vars.bobbing_anim.spd_reg
	animation_vars.bobbing_anim.curr_offs_x = animation_vars.bobbing_anim.offs_x
	animation_vars.bobbing_anim.curr_offs_y = animation_vars.bobbing_anim.offs_y

	animation_vars.status_anim.spr_curr = entity_ptr.ent.sprites.idle
	animation_vars.bobbing_anim.temp_disabled = animation_vars.bobbing_anim.is_disabled

	disp_vars.surface_is_dirty = true
} else {
	animation_vars.bobbing_anim.spd = animation_vars.bobbing_anim.is_disabled = true
	animation_vars.bobbing_anim.temp_disabled = animation_vars.bobbing_anim.is_disabled
	
	animation_vars.death_anim.is_dead = true
	entity_ptr.ent_exists = false
}