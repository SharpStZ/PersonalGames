status_anims = animation_vars.status_anim

if(status_anims.is_transitioning){
	draw_sprite_ext(status_anims.spr_last, image_index, x, y, scale, scale, 0, c_white, 1)
	
	status_anims.alpha_curr += status_anims.alpha_change_spd
	
	if(status_anims.alpha_curr >= 1){
		status_anims.alpha_curr = 1
		status_anims.is_transitioning = false
		
		status_anims.spr_last = status_anims.spr_curr
	}
}

if (disp_vars.surface_is_dirty) {
	disp_vars.surface_is_dirty = false;

	var surf_w = 50 / scale_ratio;
	var surf_h = 100 / scale_ratio;
	
	var draw_x = surf_w / 2;
	var draw_y = surf_h / 2;
	
	for (var i = 0; i < 2; i++) {
		// Free old surface and sprite if they exist
		if (surface_exists(disp_vars.surfaces[i])) {
			surface_free(disp_vars.surfaces[i]);
		}
		// Same w sprites
		if (sprite_exists(disp_vars.sprites[i])) {
			sprite_delete(disp_vars.sprites[i]);
		}
		
		// Create surface
		disp_vars.surfaces[i] = surface_create(surf_w, surf_h);
		surface_set_target(disp_vars.surfaces[i]);
		draw_clear_alpha(c_black, 0);

		// Draw contents to surface
		draw_sprite_ext(
			status_anims.spr_curr,
			i,
			draw_x,
			draw_y,
			scale / scale_ratio,
			scale / scale_ratio,
			0,
			c_white,
			status_anims.alpha_curr
		);
		
		draw_set_alpha(0.93);
		draw_set_color(#220205);
		draw_rectangle(
			draw_x + (animation_vars.stats_anim.hp_start_x - 1) * scale / scale_ratio,
			draw_y + (animation_vars.stats_anim.hp_start_y - 1) * scale / scale_ratio,
			draw_x + (animation_vars.stats_anim.hp_end_x   + 1) * scale / scale_ratio,
			draw_y + (animation_vars.stats_anim.hp_end_y   + 1) * scale / scale_ratio,
			false
		);
		draw_set_alpha(1);
		
		draw_set_color(#770511);
		draw_rectangle(
			draw_x + animation_vars.stats_anim.hp_start_x		* scale / scale_ratio,
			draw_y + animation_vars.stats_anim.hp_start_y		* scale / scale_ratio,
			draw_x + animation_vars.stats_anim.hp_end_x_curr	* scale / scale_ratio,
			draw_y + animation_vars.stats_anim.hp_end_y			* scale / scale_ratio,
			false
		);

		draw_set_color(c_white);
		draw_set_font(fnt_7px);
		
		var hp_str = curr_stats.str_health;
		var text_w = string_length(hp_str) * 1 - 4.5;
		
		current_blend_mode = gpu_get_blendmode();
		gpu_set_blendmode(bm_subtract);
		draw_set_alpha(1);
		draw_set_color(c_black);
		draw_text_transformed(
			draw_x - (text_w / scale_ratio),
			draw_y + ((animation_vars.stats_anim.stat_offset - 1.75) / scale_ratio),
			hp_str,
			scale * disp_vars.txt_scale / scale_ratio,
			scale * disp_vars.txt_scale / scale_ratio,
			0
		);
		gpu_set_blendmode(current_blend_mode);
		
		draw_set_alpha(0.8)//0.80);
		draw_set_color(c_white);
		draw_text_transformed(
			draw_x - (text_w / scale_ratio),
			draw_y + ((animation_vars.stats_anim.stat_offset - 1.75) / scale_ratio),
			hp_str,
			scale * disp_vars.txt_scale / scale_ratio,
			scale * disp_vars.txt_scale / scale_ratio,
			0
		);
		draw_set_alpha(1);
		
		draw_sprite_ext(
			spr_entity_hp,
			-1,
			draw_x + animation_vars.stats_anim.hp_icon_x * scale / scale_ratio,
			draw_y + animation_vars.stats_anim.hp_icon_y * scale / scale_ratio,
			scale / scale_ratio,
			scale / scale_ratio,
			0,
			c_white,
			1
		)
		
		disp_vars.sprites[i] = sprite_create_from_surface(disp_vars.surfaces[i], 0, 0, surf_w, surf_h, false, false, 0, 0);
		
		surface_reset_target();
	}
}

// Drawing either sprite fallback or surface
if (sprite_exists(disp_vars.sprites[image_index])) {
	draw_sprite_ext(
		disp_vars.sprites[image_index],
		0,
		x - (50 * 0.5),
		y - (100 * 0.5),
		scale_ratio,
		scale_ratio,
		0,
		c_white,
		image_alpha
	);
}
else if (surface_exists(disp_vars.surfaces[image_index])) {
	draw_surface_ext(
		disp_vars.surfaces[image_index],
		x - surface_get_width(disp_vars.surfaces[image_index]) * 0.5 * scale_ratio,
		y - surface_get_height(disp_vars.surfaces[image_index]) * 0.5 * scale_ratio,
		scale_ratio,
		scale_ratio,
		0,
		c_white,
		image_alpha
	);
}


if(animation_vars.select_anim.is_selected){
	draw_sprite_ext(animation_vars.select_anim.spr, image_index, x, y, scale, scale, 0, $DDAAFF, 
		0.55 + 0.35 * sin(frames * animation_vars.select_anim.alpha_change_spd)
	)
}
if(animation_vars.bobbing_anim.is_disabled)
	draw_sprite_ext(
		spr_entity_locked, 
		-1, 
		x + (10.75), 
		y + (10.75),
		scale,
		scale,
		0,
		c_white,
		1
	)