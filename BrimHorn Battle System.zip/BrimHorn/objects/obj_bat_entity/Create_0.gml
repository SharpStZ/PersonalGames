frames = 0

entity_ptr = variable_struct_get(variable_struct_get(global.bat_data.party, ptr_party).slots, ptr_slot)

x = variable_struct_get(variable_struct_get(global.ent_pos, ptr_party), ptr_slot).coord_x
y = variable_struct_get(variable_struct_get(global.ent_pos, ptr_party), ptr_slot).coord_y

animation_vars = {
	pos_change_anim: {
		curr_x: x,
		curr_y: y,
		last_x: x,
		last_y: y,
		
		is_changing_pos: false,
		clamp_pos: 0.05,
		spd: 15,
	},
	
	select_anim: {
		is_selected: false,
		alpha_change_spd: 0.18,
		
		spr: spr_entity_selected,
	},
	
	status_anim: {
		is_transitioning: false,
		alpha_change_spd: 0.03,
		alpha_curr: 1,
		
		spr_curr: entity_ptr.ent.sprites.idle,
		spr_last: entity_ptr.ent.sprites.idle,
	},
	
	stats_anim: {
		stat_offset: 18,
		
		hp_start_x: -10,
		hp_start_y: 22,
		hp_end_x: 18.75,
		hp_end_y: 27,
		
		hp_end_x_curr: 18.75,
		
		hp_icon_x: -16,
		hp_icon_y: 24,
	},
	
	act_anim: {
		act_frames: 90,
		
		act_party: "",
		act_slot: "",
		
		act_is_positive: true,
	},
	
	death_anim: {
		is_dead: false,
		spd_death_fade: 1 / 60,
	},
	
	bobbing_anim: {
		is_disabled: false,
		temp_disabled: false,
		
		frames_per_change: 1,
	
		// Bobbing speed which changes depending on status
		spd: 0.02,
		
		spd_reg: 0.02,
		spd_damaged: 0.6,
		spd_attack: 0,
		
		// Bobbing offset vars
		curr_offs_x: 1,
		curr_offs_y: 1,
		
		offs_x: 1,
		offs_y: 1,
		
		apply: true,
		transitioning: false,
		spd_disable: 0.01,
	},
		
	chain_anim: {
		chain_inst: noone,
		
		offs_x: 0,
		offs_y: 0,
	}
}

curr_stats = {
	max_hp: variable_clone(entity_ptr.ent.max_hp),
	curr_hp: variable_clone(entity_ptr.ent.curr_hp),
	atk: variable_clone(entity_ptr.ent.atk),
	def: variable_clone(entity_ptr.ent.def),
	spd: variable_clone(entity_ptr.ent.spd),
	
	str_health: string(entity_ptr.ent.curr_hp) + " / " + string(entity_ptr.ent.max_hp)
}

disp_vars = {
	txt_scale: 1/3,
	
	surface_is_dirty: true,
	surfaces: [0, 0],
	
	sprites: [0, 0]
}

LOC_InitialEntityData()

// Initial data set when creating an entity. Used once
function LOC_InitialEntityData(){
	surfaces[0] = surface_create(global.ent_pos_vars.cam_x / (scale * disp_vars.txt_scale), global.ent_pos_vars.cam_y / (scale * disp_vars.txt_scale))
	surfaces[1] = surface_create(global.ent_pos_vars.cam_x / (scale * disp_vars.txt_scale), global.ent_pos_vars.cam_y / (scale * disp_vars.txt_scale))

	animation_vars.stats_anim.hp_end_x_curr = (animation_vars.stats_anim.hp_end_x - animation_vars.stats_anim.hp_start_x) * (curr_stats.curr_hp / curr_stats.max_hp) + animation_vars.stats_anim.hp_start_x
	// is essentially responsible for how detailed the entity visuals are. The smaller the number, the more detailed. 
	scale_ratio = 0.25

	randomize()
	frames = irandom(2 * 1 / animation_vars.bobbing_anim.spd)
}

// Pre-move stage
function LOC_ChangeEntitySelectionStatus(select_status){
	animation_vars.select_anim.is_selected = select_status
}

// Anim funcs
function LOC_LockEnemyPosition(is_locked){
	animation_vars.bobbing_anim.is_disabled = is_locked
	animation_vars.bobbing_anim.temp_disabled = is_locked
}

// WIP
function LOC_CreateChain(){
	
}

// Battle move stage
function LOC_UpdateEntityPosition(ent_party, ent_slot){
	//show_error("MOVE HAPPENS!", true)
	
	ptr_party = ent_party
	ptr_slot = ent_slot
	
	entity_ptr = variable_struct_get(variable_struct_get(global.bat_data.party, ptr_party).slots, ptr_slot)
	
	animation_vars.pos_change_anim.last_x = variable_clone(animation_vars.pos_change_anim.curr_x)
	animation_vars.pos_change_anim.last_y = variable_clone(animation_vars.pos_change_anim.curr_y)
	
	animation_vars.pos_change_anim.curr_x = variable_struct_get(variable_struct_get(global.ent_pos, ptr_party), ptr_slot).coord_x
	animation_vars.pos_change_anim.curr_y = variable_struct_get(variable_struct_get(global.ent_pos, ptr_party), ptr_slot).coord_y
	
	animation_vars.pos_change_anim.is_changing_pos = true
	
	animation_vars.bobbing_anim.transitioning = true
	animation_vars.bobbing_anim.apply = true
	
	LOC_UpdateEntityStats()
}

// Checks for one stat that had changed, updates it and then makes entities animate based on em
function LOC_UpdateEntityStats(){
	var file = file_text_open_append("debug_choices.txt")
	file_text_write_string(file, "\n")
	file_text_write_string(file, "[LOC-UPD-ENT-STS::] Happens!\n")
	
	file_text_close(file)
	file = file_text_open_append("debug_choices.txt")
	 
	stats = ["max_hp", "curr_hp", "atk", "def", "spd"]
	stat_change = "[none]"
	
	
	for(i = 0; i < array_length(stats); i++){
		if(variable_struct_get(curr_stats, stats[i]) != variable_struct_get(entity_ptr.ent, stats[i])) {
			stat_change = stats[i]
			break;
		}
	}
	
	file_text_write_string(file, "[LOC_UPD-ENT_STS::] Stat being updated: " + stat_change + "\n")
	
	if(stat_change != "[none]"){
		if(variable_struct_get(entity_ptr.ent, stat_change) < variable_struct_get(curr_stats, stat_change))
			LOC_MakeEntityDamaged()
		else if(variable_struct_get(entity_ptr.ent, stat_change) > variable_struct_get(curr_stats, stat_change))
			LOC_MakeEntityRejuvenated()
		
		file_text_write_string(file, "[LOC_UPD-ENT_STS::] Replacement stat " + stat_change + ", which is equal to " + string(variable_struct_get(entity_ptr.ent, stat_change)) + ", is replacing the current " + stat_change + ", equal to " + string(variable_struct_get(curr_stats, stat_change)) + "\n")
		file_text_close(file)
		file = file_text_open_append("debug_choices.txt")
		
		variable_struct_set(curr_stats, stat_change, variable_struct_get(entity_ptr.ent, stat_change))
		
		animation_vars.stats_anim.hp_end_x_curr = 
		(animation_vars.stats_anim.hp_end_x 
		- animation_vars.stats_anim.hp_start_x) 
		* (curr_stats.curr_hp 
		/ curr_stats.max_hp) 
		+ animation_vars.stats_anim.hp_start_x
		
		curr_stats.str_health = string(entity_ptr.ent.curr_hp) + " / " + string(entity_ptr.ent.max_hp)
		
		disp_vars.surface_is_dirty = true
	}
	
	file_text_close(file)
}

function LOC_MakeEntityActToPosition(ent_party, ent_slot, is_positive){
	
}

function LOC_MakeEntityDamaged(){
	animation_vars.bobbing_anim.spd = animation_vars.bobbing_anim.spd_damaged
	animation_vars.bobbing_anim.curr_offs_x = animation_vars.bobbing_anim.offs_x / 5
	animation_vars.bobbing_anim.curr_offs_y = animation_vars.bobbing_anim.offs_y / 5
	
	animation_vars.status_anim.spr_curr = entity_ptr.ent.sprites.damaged
	
	disp_vars.surface_is_dirty = true
	
	animation_vars.bobbing_anim.temp_disabled = false
	
	alarm[0] = 30
}

function LOC_MakeEntityRejuvenated(){
	
}

function LOC_SelfDestruct(){
	if(sprite_exists(disp_vars.sprites[0])) sprite_delete(disp_vars.sprites[0])
	if(sprite_exists(disp_vars.sprites[1])) sprite_delete(disp_vars.sprites[1])
	
	if(surface_exists(disp_vars.surfaces[0])) surface_free(disp_vars.surfaces[0])
	if(surface_exists(disp_vars.surfaces[1])) surface_free(disp_vars.surfaces[1])
	
	if(instance_exists(animation_vars.chain_anim.chain_inst)) instance_destroy(animation_vars.chain_anim.chain_inst)
	
	entity_ptr.ent_exists = false
	
	instance_destroy()
}