frames++

if(animation_vars.death_anim.is_dead){
	image_alpha -= animation_vars.death_anim.spd_death_fade
	
	if(image_alpha <= 0) LOC_SelfDestruct()
}

// When entity moves positions, it eases into that position
if(animation_vars.pos_change_anim.is_changing_pos){
	pos_anims = animation_vars.pos_change_anim
	
	pos_anims.last_x += (pos_anims.curr_x - pos_anims.last_x) / pos_anims.spd
	pos_anims.last_y += (pos_anims.curr_y - pos_anims.last_y) / pos_anims.spd
	
	if(abs(pos_anims.curr_x - pos_anims.last_x) <= pos_anims.clamp_pos){
		pos_anims.is_changing_pos = false
		
		pos_anims.last_x = pos_anims.curr_x
		pos_anims.last_y = pos_anims.curr_y
		
		pos_anims.transitioning = true
		pos_anims.apply = true
	}
}

if(!animation_vars.bobbing_anim.temp_disabled){
	bob_anims = animation_vars.bobbing_anim
	
	
	// Infinity-shaped entity position bobbing!
	if(bob_anims.apply and frames % bob_anims.frames_per_change == 0){
		pos_anims = animation_vars.pos_change_anim
		
		x = round((	pos_anims.last_x + bob_anims.offs_x * cos(frames * bob_anims.spd    )		) * 4) / 4
		y = round((	pos_anims.last_y + bob_anims.offs_y * sin(frames * bob_anims.spd * 2) / 2	) * 4) / 4
	}
	
	else if(bob_anims.transitioning){
		
		if(!bob_anims.apply){
			bob_anims.curr_offs_x -= bob_anims.spd_disable
			bob_anims.curr_offs_y -= bob_anims.spd_disable
			
			if(bob_anims.curr_offs_x <= 0 or bob_anims.curr_offs_y <= 0){
				bob_anims.curr_offs_x = 0
				bob_anims.curr_offs_y = 0
				
				bob_anims.transition = false
			}
		} else {
			bob_anims.curr_offs_x += bob_anims.spd_disable
			bob_anims.curr_offs_y += bob_anims.spd_disable
			
			if(bob_anims.curr_offs_x >= bob_anims.offs_x and 
			   bob_anims.curr_offs_y >= bob_anims.offs_y){
					
				bob_anims.curr_offs_x = bob_anims.offs_x
				bob_anims.curr_offs_y = bob_anims.offs_y
				
				bob_anims.transition = false
			}
		}
	}
}