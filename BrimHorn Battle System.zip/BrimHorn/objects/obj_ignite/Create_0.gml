function BAT_CreateEntityInBatDataStorage(ent_party, ent_slot, sumn_name, sumn_type){
	slot_str = variable_struct_get(variable_struct_get(global.bat_data.party, ent_party).slots, ent_slot)

	slot_str.ent = variable_struct_get(global.sumn_dat_dict[?sumn_name], sumn_type)
	slot_str.can_move = true
	slot_str.ent_exists = true
	slot_str.ent_name = sumn_type + " " + sumn_name
}

file_delete("debug_choices.txt")

global.bat_data.party.player.slots.leader.ent = global.leader_dat_dict[?"player"]
global.bat_data.party.player.slots.leader.can_move = true
global.bat_data.party.player.slots.leader.ent_exists = true

global.bat_data.party.enemy.slots.leader.ent = global.leader_dat_dict[?"enemy"]
global.bat_data.party.enemy.slots.leader.can_move = true
global.bat_data.party.enemy.slots.leader.ent_exists = true

BAT_CreateEntityInBatDataStorage("player", "one", "geode", "beefy")
BAT_CreateEntityInBatDataStorage("player", "two", "needle", "beefy")
BAT_CreateEntityInBatDataStorage("player", "three", "slime", "normal")

BAT_CreateEntityInBatDataStorage("enemy", "one", "geode", "weak")
BAT_CreateEntityInBatDataStorage("enemy", "two", "geode", "weak")
BAT_CreateEntityInBatDataStorage("enemy", "three", "geode", "weak")

BAT_CreateEntityInBatDataStorage("neutral", "one", "slime", "weak")
BAT_CreateEntityInBatDataStorage("neutral", "two", "slime", "weak")
BAT_CreateEntityInBatDataStorage("neutral", "three", "slime", "weak")


// Manual refs to 'bake' sprites into existance.
// GMS2 thinks these are unused if not interacted with directly beforehand,
// so this horrible redundant thing MUST exist.
// Look away, dont extend the struct... I warned you...
{ sprite_bakery = [

	// Bakes T1 Geode summons
	spr_summon_geode_weak_attack,
	spr_summon_geode_weak_damaged,
	spr_summon_geode_weak_idle,
	
	spr_summon_geode_normal_attack,
	spr_summon_geode_normal_damaged,
	spr_summon_geode_normal_idle,
	
	spr_summon_geode_beefy_attack,
	spr_summon_geode_beefy_damaged,
	spr_summon_geode_beefy_idle,

	// Bakes T1 Needle summons
	spr_summon_needle_weak_attack,
	spr_summon_needle_weak_damaged,
	spr_summon_needle_weak_idle,
	
	spr_summon_needle_normal_attack,
	spr_summon_needle_normal_damaged,
	spr_summon_needle_normal_idle,
	
	spr_summon_needle_beefy_attack,
	spr_summon_needle_beefy_damaged,
	spr_summon_needle_beefy_idle,
	
	// Bakes T1 Slime summons
	spr_summon_slime_weak_attack,
	spr_summon_slime_weak_damaged,
	spr_summon_slime_weak_idle,
	
	spr_summon_slime_normal_attack,
	spr_summon_slime_normal_damaged,
	spr_summon_slime_normal_idle,
	
	spr_summon_slime_beefy_attack,
	spr_summon_slime_beefy_damaged,
	spr_summon_slime_beefy_idle,
	
	// Bakes T3 Demon summons
	spr_summon_demon_beefy_attack,
	spr_summon_demon_beefy_damaged,
	spr_summon_demon_beefy_idle,
]}