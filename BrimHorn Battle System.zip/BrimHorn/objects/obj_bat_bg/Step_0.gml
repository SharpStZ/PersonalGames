frames++
image_angle = ang * sin(frames * spd)