draw_sprite_ext(images[1], -1, x, y, 1, 1, -ang * sin(frames * spd * 1.8) + 180, c_white, 0.75)
draw_sprite_ext(images[0], -1, x, y, 1, 1, ang * sin(frames * spd), c_white, 0.5)