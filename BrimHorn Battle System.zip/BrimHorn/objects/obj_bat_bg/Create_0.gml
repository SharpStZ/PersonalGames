images = [
	spr_battlebg,
	spr_battlebg2
]

frames = 0
ang = 1
spd = 0.03