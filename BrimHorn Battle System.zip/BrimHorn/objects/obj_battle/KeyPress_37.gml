slot_curr = menu_ptr.slot
slot_change = menu_ptr.slot	

party_curr = menu_ptr.party
party_change = menu_ptr.party	

// Is choosing who casts the move
if(bat_status.is_choosing_caster and !keyboard_check(vk_alt)){
	
	// Checks who performs the selection
	// Switches to maintain consistency across input code readability, even if some seem redundant here.
	switch menu_ptr.party {
		case "player":
			switch menu_ptr.slot {
				case "two":
					if(BAT_EntityInstanceExists("player", "leader"))
						slot_change = "leader"
					else if(BAT_EntityInstanceExists("player", "one"))
						slot_change = "one"
					else if(BAT_EntityInstanceExists("player", "three"))
						slot_change = "three"
				break;
			}
		break;
		
		case "enemy":
			switch menu_ptr.slot {
				case "one":
				case "leader":
				case "three":
					if(BAT_EntityInstanceExists("enemy", "two"))
						slot_change = "two"
				break;
			}
		break;
		
		case "neutral":
			switch menu_ptr.slot {
				case "two":
				case "three":
					if(BAT_EntityInstanceExists("neutral", "one"))
						slot_change = "one"
				break;
			}
		break;
	}
	
	if(slot_curr != slot_change){
		BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, slot_curr, false)
		BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, slot_change, true)
									
		menu_ptr.slot = slot_change
	}
}

// Is choosing a party
else if(bat_status.is_choosing_caster and keyboard_check(vk_alt)){
	
	// When switching parties from 
	if(array_contains(variable_struct_get(bat_status.aval_parties, bat_status.who_moves), "player") and menu_ptr.party != "player"){
		if(BAT_EntityInstanceExists("player", "leader")){
			party_change = "player"
			slot_change = "leader"
		}
		else if(BAT_EntityInstanceExists("player", "two")){
			party_change = "player"
			slot_change = "two"
		}
		else if(BAT_EntityInstanceExists("player", "one")){
			party_change = "player"
			slot_change = "one"
		}
		else if(BAT_EntityInstanceExists("player", "three")){
			party_change = "player"
			slot_change = "three"
		}
	}
	
	if(party_curr != party_change){
		BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, menu_ptr.slot, false)
		BAT_ChangeSelectionStatusOfEntity(party_change, slot_change, true)
		
		menu_ptr.party = party_change
		menu_ptr.slot = slot_change
	}
}



// Is choosing move entity slot
else if(bat_status.is_choosing_move_entities and !keyboard_check(vk_alt)){
		// Checks who performs the selection
	// Switches to maintain consistency across input code readability, even if some seem redundant here.
	switch menu_ptr.party {
		case "player":
			switch menu_ptr.slot {
				case "two":
					if(BAT_EntityInstanceExists("player", "leader")
						and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"player"], "leader"))
						slot_change = "leader"
					else if(BAT_EntityInstanceExists("player", "one")
						and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"player"], "one"))
						slot_change = "one"
					else if(BAT_EntityInstanceExists("player", "three")
						and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"player"], "three"))
						slot_change = "three"
				break;
			}
		break;
		
		case "enemy":
			switch menu_ptr.slot {
				case "one":
				case "leader":
				case "three":
					if(BAT_EntityInstanceExists("enemy", "two")
						and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"enemy"], "two"))
						slot_change = "two"
				break;
			}
		break;
		
		case "neutral":
			switch menu_ptr.slot {
				case "two":
				case "three":
					if(BAT_EntityInstanceExists("neutral", "one")
						and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"neutral"], "one"))
						slot_change = "one"
				break;
			}
		break;
	}
	
	if(slot_curr != slot_change){
		BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, slot_curr, false)
		BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, slot_change, true)
									
		menu_ptr.slot = slot_change
	}
}
	
// Is choosing move entity party
else if(bat_status.is_choosing_move_entities and keyboard_check(vk_alt)){
	
	// When switching parties from 
	if(array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).party, "player") and menu_ptr.party != "player"){
		if(BAT_EntityInstanceExists("player", "leader") 
			and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"player"], "leader")){
			party_change = "player"
			slot_change = "leader"
		}
		else if(BAT_EntityInstanceExists("player", "two")
			and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"player"], "two")){
			party_change = "player"
			slot_change = "two"
		}
		else if(BAT_EntityInstanceExists("player", "one")
			and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"player"], "one")){
			party_change = "player"
			slot_change = "one"
		}
		else if(BAT_EntityInstanceExists("player", "three")
			and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"player"], "three")){
			party_change = "player"
			slot_change = "three"
		}
	}
	
	if(party_curr != party_change){
		BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, menu_ptr.slot, false)
		BAT_ChangeSelectionStatusOfEntity(party_change, slot_change, true)
		
		menu_ptr.party = party_change
		menu_ptr.slot = slot_change
	}
}