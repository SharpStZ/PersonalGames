/// @description Automatic turn system
if(bat_status.is_executing_attack) {
	BAT_Select()
	alarm[1] = 20
}