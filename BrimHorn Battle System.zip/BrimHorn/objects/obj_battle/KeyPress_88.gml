if(bat_status.is_choosing_move){
	surface_is_dirty = true
	
	bat_status.is_choosing_caster = true
	bat_status.is_choosing_move = false
}