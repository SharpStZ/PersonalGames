if(bat_status.who_moves == "player" and !bat_status.is_executing_attack) 
	BAT_Select()