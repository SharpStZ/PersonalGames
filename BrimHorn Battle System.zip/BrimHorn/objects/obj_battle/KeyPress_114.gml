ld1_ptr = BAT_RetrieveEntityPointer("player", "leader")
ld1_ptr.ent_inst.LOC_UpdateEntityPosition("enemy", "leader")

ld2_ptr = BAT_RetrieveEntityPointer("enemy", "leader")
ld2_ptr.ent_inst.LOC_UpdateEntityPosition("player", "leader")