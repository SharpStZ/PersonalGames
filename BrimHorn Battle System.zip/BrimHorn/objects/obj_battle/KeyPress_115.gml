BAT_GenerateAllExistingEntities()
BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, menu_ptr.slot, true)