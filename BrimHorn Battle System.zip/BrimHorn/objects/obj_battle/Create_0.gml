depth = -5000
frames = 0


ent_parties = ["player", "enemy", "neutral"]
ent_slots   = ["one", "two", "three", "leader"]

// -- DEBUG VARS -- //
draw_all_boxes = false

// -- BATTLE CHOICE VARS -- //
bat_status = {
	// -- ENT SELECTION VARS -- //
	is_choosing_caster: true,

	who_moves: "player",
	aval_parties: {
		player: ["player"],
		enemy: ["enemy"],
		neutral: ["neutral"]
	},
	
	// -- MOVE SELECTION VARS -- //
	is_choosing_move: false,
	
	// -- MOVE APPLICATION VARS -- //
	is_applying_move: false,
	is_choosing_move_entities: false,
	is_executing_attack: false,
	action_changed: true,
	
	actions_arr: [],
	
	action_index: 0,
	action_curr: false,
	action_cache: false, 
	
	// Choice vars
	choices: {
		attacker: 0,
		target: 0,
	},
	
	move_curr_status: "* Applying move!",
	curr_choosing: {
		who: "",		// target / attacker
		what: "",		// party  / slot
	},
	
	// Execution vars
	curr_attackers: [],
	curr_attackers_index: 0,
	
	curr_targets: [],
	curr_targets_index: 0,
	
	entities_extracted: false,
	step_executed: true
}

menu_ptr = {
	party: "player",
	slot: "leader",
	curr_ent_ptr: noone,
	
	move: "none",
}

move_ptr = {
	party: "player"
}


// -- BOX DISP VARS -- //
screen_mid_x = x + global.ent_pos_vars.cam_x / 2
screen_mid_y = y + global.ent_pos_vars.cam_y / 2

surface = surface_create(global.ent_pos_vars.cam_x * 3, global.ent_pos_vars.cam_y * 3)
surface_spr = 0
surface_is_dirty = true

id_bg = instance_create_depth(screen_mid_x, screen_mid_y, depth + 1000, obj_bat_bg)


// -- MENU DISP VARS -- //
menu_vars = {
	// -- BORDER VARS -- //
	col_in: c_black,
	col_out: c_white,
	
	border_thickness: 1.5,
	
	
	start_x: 42,
	start_y: 123,
	
	end_x: global.ent_pos_vars.cam_x - 42,
	end_y: global.ent_pos_vars.cam_y - 3,
	
	// -- TEXT VARS -- //
	text_fnt: fnt_7px,
	text_col: c_white,
	text_scale: 0.5,
	
	text_line_spacing: 8,
	text_line_length: 80,
	
	text_start_x: 50,
	text_start_y: 129,
	
	// -- SELECTION VARS -- //
	
	sel_string: "->",
	sel_spd: 0.1,
	sel_offs_x: 2,
	sel_offs_init_x: 2,
	
	sel_col: #FF77AA
}

alarm[0] = 1

function BAT_GenerateAllExistingEntities(){
	party_vars = ["player", "enemy", "neutral"]
	slot_vars = ["one", "two", "three", "leader"]
	
	for(i = 0; i < array_length(party_vars); i++){
		party = party_vars[i]
		party_struct = variable_struct_get(global.bat_data.party, party)
		pos_party_struct = variable_struct_get(global.ent_pos, party)
		
		for(j = 0; j < array_length(slot_vars); j++){
			slot = slot_vars[j]
			slot_struct = variable_struct_get(party_struct.slots, slot)
			pos_slot_struct = variable_struct_get(pos_party_struct, slot)
			
			if(party == "neutral" and slot == "leader") continue;
			
			if(slot_struct.ent_exists){
				if(slot_struct.ent_inst != noone and instance_exists(slot_struct.ent_inst)) {
					slot_struct.ent_inst.LOC_SelfDestruct()
				}
				slot_struct.ent_inst = instance_create_depth(0, 0, depth - 1000, obj_bat_entity, {
					scale: global.ent_pos_vars.ent_scale,
					ptr_party: party,
					ptr_slot: slot,
					ent_offs_x: x,
					ent_offs_y: y,
				})
				if(slot == "leader") slot_struct.ent_inst.LOC_LockEnemyPosition(true)
			}
		}
	}
}
	
function BAT_ChangeSelectionStatusOfEntity(ent_party, ent_slot, sel_status){
	variable_struct_get(variable_struct_get(global.bat_data.party, ent_party).slots,  ent_slot).ent_inst.LOC_ChangeEntitySelectionStatus(sel_status)
}
	
function BAT_ChangeSelectionStatusOfAllEntities(sel_status){
	party_vars = ["player", "enemy", "neutral"]
	slot_vars = ["one", "two", "three", "leader"]
	
	for(i = 0; i < array_length(party_vars); i++){
		party = party_vars[i]
		
		for(j = 0; j < array_length(slot_vars); j++){
			slot = slot_vars[j]
			if(slot == "leader" and party == "neutral") continue
			
			if(BAT_EntityInstanceExists(party, slot)) BAT_ChangeSelectionStatusOfEntity(party, slot, sel_status)
		}
	}
}
	
function BAT_EntityInstanceExists(ent_party, ent_slot){
	return variable_struct_get(variable_struct_get(global.bat_data.party, ent_party).slots, ent_slot).ent_exists
}
	
function BAT_SetInitValidChoicePointers(){
	slot_order = ["leader", "two", "one", "three"]
	party_order = ["player", "enemy", "neutral"]
	
	if(bat_status.is_choosing_move_entities){
		is_broken = false
		for(i = 0; i < array_length(party_order); i++){
			party = party_order[i]
			
			if(!array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).party, party)) continue
			
			for(j = 0; j < array_length(slot_order); j++){
				slot = slot_order[j]
				
				if(array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?party], slot) and BAT_EntityInstanceExists(party, slot)){
					BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, menu_ptr.slot, false)
					BAT_ChangeSelectionStatusOfEntity(party, slot, true)
					
					menu_ptr.party = party
					menu_ptr.slot = slot
					
					is_broken = true
					break
				}
			}
			if(is_broken) break
		}
	} 
	else {
		switch bat_status.who_moves {
			case "player":
				is_broken = false
				for(i = 0; i < array_length(bat_status.aval_parties.player); i++){
					party = bat_status.aval_parties.player[i]
					
					for(j = 0; j < array_length(slot_order); j++){
						slot = slot_order[j]
						
						if(BAT_EntityInstanceExists(party, slot)){
							BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, menu_ptr.slot, false)
							BAT_ChangeSelectionStatusOfEntity(party, slot, true)
							
							menu_ptr.party = party
							menu_ptr.slot = slot
							
							is_broken = true
							break
						}
						if(is_broken) break
					}
				}
			break;
			
			case "enemy":
				is_broken = false
				for(i = 0; i < array_length(bat_status.aval_parties.enemy); i++){
					party = bat_status.aval_parties.enemy[i]
					
					for(j = 0; j < array_length(slot_order); j++){
						slot = slot_order[j]
						
						if(BAT_EntityInstanceExists(party, slot)){
							BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, menu_ptr.slot, false)
							BAT_ChangeSelectionStatusOfEntity(party, slot, true)
							
							menu_ptr.party = party
							menu_ptr.slot = slot
							
							is_broken = true
							break
						}
						if(is_broken) break
					}
				}
			break;
		}
	}
}
	
function BAT_ResetBatStatus(){
	bat_status.is_applying_move = false
	bat_status.is_choosing_move = false
	bat_status.is_choosing_move_entities = false
	bat_status.is_executing_attack = false
	bat_status.is_choosing_caster = true
	
	bat_status.actions_arr = []
	bat_status.action_index = 0
	bat_status.action_curr = false
	bat_status.action_cache = false
	
	bat_status.choices = {
		attacker: 0,
		target: 0
	}
	
	bat_status.curr_choosing = {
		who: "",
		what: ""
	}
	
	bat_status.curr_attackers = []
	bat_status.curr_attackers_index = 0
	
	bat_status.curr_targets = []
	bat_status.curr_targets_index = 0
	
	bat_status.move_curr_status = "* Applying move!"
	
	bat_status.entities_extracted = false
	bat_status.step_executed = true
}
	
function BAT_Select(){
	if(bat_status.is_choosing_move_entities){
		surface_is_dirty = true
	
		if(bat_status.curr_choosing.what == "party"){

			variable_struct_set(variable_struct_get(bat_status.action_curr, bat_status.curr_choosing.who), "party", [menu_ptr.party])
			variable_struct_set(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who), "party", [menu_ptr.party])

		} 
		else if(bat_status.curr_choosing.what == "slot"){

			variable_struct_set(variable_struct_get(bat_status.action_curr, bat_status.curr_choosing.who), "slot", [menu_ptr.slot])
			variable_struct_set(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who), "slot", [menu_ptr.slot])
		}
	}

	if(bat_status.is_applying_move){

		var file = file_text_open_append("debug_choices.txt")
		file_text_write_string(file, "\n")
	
		surface_is_dirty = true
	
		if(bat_status.is_executing_attack and !bat_status.step_executed and !bat_status.is_choosing_move_entities){
			file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 16}] Attacker's index: " + string(bat_status.curr_attackers_index) + "\n")
			file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 16}] Target's index: " + string(bat_status.curr_targets_index) + "\n")
			file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 16}] Attacker's arr size: " + string(array_length(bat_status.curr_attackers)) + "\n")
			file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 16}] Target's arr size: " + string(array_length(bat_status.curr_targets)) + "\n")
		
			//show_error(
			//	"Attacker: " + bat_status.curr_attackers[bat_status.curr_attackers_index].party + " " + bat_status.curr_attackers[bat_status.curr_attackers_index].slot + 
			//	"Target: " + bat_status.curr_targets[bat_status.curr_targets_index].party + " " + bat_status.curr_targets[bat_status.curr_targets_index].slot,
			//	true
			//)
		
			if(bat_status.action_curr.can_be_executed){
				bat_status.action_curr = ENT_EntityMoveExecuteStep(
					bat_status.action_curr, 
					bat_status.curr_attackers[bat_status.curr_attackers_index], 
					bat_status.curr_targets[bat_status.curr_targets_index],
					{
						party: bat_status.action_curr.middleman.party,
						slot: bat_status.action_curr.middleman.slot
					}
				)

			}
			else {
				bat_status.move_curr_status = "Step cannot be executed! Skipping!"
			}

			bat_status.step_executed = true
		
			attacker_ptr = BAT_RetrieveEntityPointer(bat_status.curr_attackers[bat_status.curr_attackers_index].party, bat_status.curr_attackers[bat_status.curr_attackers_index].slot)
			target_ptr = BAT_RetrieveEntityPointer(bat_status.curr_targets[bat_status.curr_targets_index].party, bat_status.curr_targets[bat_status.curr_targets_index].slot)
		
			attacker_ptr.ent_inst.LOC_UpdateEntityStats()
			target_ptr.ent_inst.LOC_UpdateEntityStats()
		
			bat_status.curr_targets_index++
			if(bat_status.curr_targets_index >= array_length(bat_status.curr_targets)){
				bat_status.curr_targets_index = 0
				bat_status.curr_attackers_index++
			
				if(bat_status.curr_attackers_index >= array_length(bat_status.curr_attackers)){
					bat_status.curr_attackers_index = 0
					bat_status.is_executing_attack = false
				
					bat_status.action_changed = true
				}
			}
		}
		else if(bat_status.step_executed and bat_status.action_index >= array_length(bat_status.actions_arr)){
			BAT_ResetBatStatus()
		
			BAT_SetInitValidChoicePointers()
		
			surface_is_dirty = true
		}
		else if(bat_status.step_executed and !bat_status.is_choosing_move_entities) {
			if(is_struct(bat_status.action_curr)){

			}
		
			bat_status.action_cache = variable_clone(bat_status.action_curr)
		
			bat_status.action_curr	= bat_status.actions_arr[bat_status.action_index]
			bat_status.action_index++
		
			bat_status.action_changed = true
			bat_status.entities_extracted = false
			bat_status.step_executed = false
		
			if(true){ // Debug funcs
			file_text_write_string(file, "\n")
			file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 96}::] Happens!\n")
			file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 96}::] Current action's stats before change:\n")
			file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 96}::] > attacker's parties:\n")
			for(i = 0; i < array_length(bat_status.action_curr.attacker.party); i++){
				party = bat_status.action_curr.attacker.party[i]
				file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 96}::]    > " + party + "\n")
			}
			file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 96}::] > attacker's slots:\n")
			for(i = 0; i < array_length(bat_status.action_curr.attacker.slot); i++){
				slot = bat_status.action_curr.attacker.slot[i]
				file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 96}::]    > " + slot + "\n")
			}
			file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 96}::] > attacker's specifs:\n")
			for(i = 0; i < array_length(bat_status.action_curr.attacker.spec); i++){
				spec = bat_status.action_curr.attacker.spec[i]
				file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 96}::]    > " + spec.party + "_" + spec.slot + "\n")
			}
		
		
			file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 96}::] > target's parties:\n")
			for(i = 0; i < array_length(bat_status.action_curr.target.party); i++){
				party = bat_status.action_curr.target.party[i]
				file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 96}::]    > " + party + "\n")
			}
			file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 96}::] > target's slots:\n")
			for(i = 0; i < array_length(bat_status.action_curr.target.slot); i++){
				slot = bat_status.action_curr.target.slot[i]
				file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 96}::]    > " + slot + "\n")
			}
			file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 96}::] > target's specifs:\n")
			for(i = 0; i < array_length(bat_status.action_curr.target.spec); i++){
				spec = bat_status.action_curr.target.spec[i]
				file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 96}::]    > " + spec.party + "_" + spec.slot + "\n")
			}
			}
		} 
	
		if(bat_status.is_applying_move){
			if(!bat_status.action_curr.can_be_executed){
				bat_status.move_curr_status = "* Action index " + string(bat_status.action_index - 1) + " can't be executed!"
			
				bat_status.step_executed = true
				bat_status.is_choosing_move_entities = false
			}
			else {
				if(!bat_status.entities_extracted){
					bat_status.action_curr = ENT_EntityMoveRefine(bat_status.action_curr, bat_status.action_cache)
		
					bat_status.choices.attacker = ENT_EntityMoveExtractEntitiesChoice(bat_status.action_curr, "attacker")
					bat_status.choices.target	= ENT_EntityMoveExtractEntitiesChoice(bat_status.action_curr, "target")
			
					bat_status.entities_extracted = true
				}
		
				bat_status.is_choosing_move_entities = true
		
				if(bat_status.choices.attacker.can_choose_party) {
					bat_status.curr_choosing.who = "attacker"
					bat_status.curr_choosing.what = "party"
					bat_status.choices.attacker.can_choose_party = false
			
				} else if (bat_status.choices.attacker.can_choose_slot) {
					bat_status.curr_choosing.who = "attacker"
					bat_status.curr_choosing.what = "slot"
					bat_status.choices.attacker.can_choose_slot = false
			
				} else if (bat_status.choices.target.can_choose_party) {
					bat_status.curr_choosing.who = "target"
					bat_status.curr_choosing.what = "party"
					bat_status.choices.target.can_choose_party = false
			
				} else if (bat_status.choices.target.can_choose_slot) {
					bat_status.curr_choosing.who = "target"
					bat_status.curr_choosing.what = "slot"
					bat_status.choices.target.can_choose_slot = false
			
			
				} else {
					bat_status.is_choosing_move_entities = false
					bat_status.is_executing_attack = true
				
			
					bat_status.curr_attackers = ENT_EntityMoveExtractEntitiesBattle(bat_status.action_curr, "attacker")
					bat_status.curr_targets = ENT_EntityMoveExtractEntitiesBattle(bat_status.action_curr, "target")
				
					BAT_ChangeSelectionStatusOfAllEntities(false)
				
					bat_status.curr_attackers_index = 0
					bat_status.curr_targets_index = 0
				
					bat_status.move_curr_status = "* All move entities chosen, Executing Step! \n\n"
					bat_status.move_curr_status += 
						"* [ " + string(bat_status.curr_attackers[bat_status.curr_attackers_index].party) + "_" + string(bat_status.curr_attackers[bat_status.curr_attackers_index].slot) +
						" ] attacks [ " + 
						string(bat_status.curr_targets[bat_status.curr_targets_index].party) + "_" + string(bat_status.curr_targets[bat_status.curr_targets_index].slot) +
						" ]\nAct type: [ " + bat_status.action_curr.act_type + " ]!"
				
					bat_status.move_curr_status = bat_status.move_curr_status
					
					alarm[1] = 20
					
					if(true){ // Debug funcs
					file_text_write_string(file, "\n")
					file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 179}::] READY FOR EXECUTION OF ACTION INDEX " + string(bat_status.action_index - 1) + "\n")
					file_text_write_string(file, "\n")
		
					file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 179}::] Current action's stats after change:\n")
					file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 179}::] > attacker's parties:\n")
					for(i = 0; i < array_length(bat_status.action_curr.attacker.party); i++){
						party = bat_status.action_curr.attacker.party[i]
						file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 179}::]    > " + party + "\n")
					}
					file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 179}::] > attacker's slots:\n")
					for(i = 0; i < array_length(bat_status.action_curr.attacker.slot); i++){
						slot = bat_status.action_curr.attacker.slot[i]
						file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 179}::]    > " + slot + "\n")
					}
					file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 179}::] > attacker's specifs:\n")
					for(i = 0; i < array_length(bat_status.action_curr.attacker.spec); i++){
						spec = bat_status.action_curr.attacker.spec[i]
						file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 179}::]    > " + spec.party + "_" + spec.slot + "\n")
					}
		
		
					file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 179}::] > target's parties:\n")
					for(i = 0; i < array_length(bat_status.action_curr.target.party); i++){
						party = bat_status.action_curr.target.party[i]
						file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 179}::]    > " + party + "\n")
					}
					file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 179}::] > target's slots:\n")
					for(i = 0; i < array_length(bat_status.action_curr.target.slot); i++){
						slot = bat_status.action_curr.target.slot[i]
						file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 179}::]    > " + slot + "\n")
					}
					file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 179}::] > target's specifs:\n")
					for(i = 0; i < array_length(bat_status.action_curr.target.spec); i++){
						spec = bat_status.action_curr.target.spec[i]
						file_text_write_string(file, "[OBJ_BAT-KP'Z'{ln 179}::]    > " + spec.party + "_" + spec.slot + "\n")
					}
					}
				}
		
				if(bat_status.is_choosing_move_entities){
					bat_status.move_curr_status = "* Currently choosing " + bat_status.curr_choosing.who + "'s " + bat_status.curr_choosing.what + "..."
					BAT_SetInitValidChoicePointers()
				} //file_text_close
			}
		}
	
		file_text_close(file)
	}

	else if(bat_status.is_choosing_caster){
		bat_status.curr_ent_ptr = BAT_RetrieveEntityPointer(menu_ptr.party, menu_ptr.slot)
	
		if(array_length(bat_status.curr_ent_ptr.ent.moves) != 0){
			surface_is_dirty = true
		
			bat_status.is_choosing_caster = false
			bat_status.is_choosing_move = true
		
			bat_status.loc_moves = bat_status.curr_ent_ptr.ent.moves
			bat_status.curr_index = 0
		
			menu_ptr.move = BAT_RetrieveEntityPointer(menu_ptr.party, menu_ptr.slot).ent.moves[bat_status.curr_index]
		}
	}
	else if(bat_status.is_choosing_move){
	
		// Later changed for check whether move is valid with current layout
		// EX: Moves such as "swap" mustn't work if there's no summon to swap with
		if(true){
			BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, menu_ptr.slot, false)
		
			surface_is_dirty = true
		
			bat_status.is_choosing_move = false
			bat_status.is_applying_move = true
		
			bat_status.actions_arr = ENT_EntityMoveCompile(global.ent_move_dat_dict[?menu_ptr.move], menu_ptr.party, menu_ptr.slot)
		
			bat_status.middleman_party = menu_ptr.party
			bat_status.middleman_slot = menu_ptr.slot
		
			bat_status.action_index = 0
		}
	}
}