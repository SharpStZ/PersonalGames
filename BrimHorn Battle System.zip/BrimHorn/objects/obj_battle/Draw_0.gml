frames++;

if (surface_is_dirty) {
	surface_is_dirty = false;

	// Clean up old surface and sprite if they exist
	if (surface_exists(surface)) surface_free(surface);
	if (sprite_exists(surface_spr)) sprite_delete(surface_spr);

	var surf_w = global.ent_pos_vars.cam_x / menu_vars.text_scale;
	var surf_h = global.ent_pos_vars.cam_y / menu_vars.text_scale;
	surface = surface_create(surf_w, surf_h);
	surface_set_target(surface);

	// Draws initial menu rectangle
	draw_set_color(menu_vars.col_out);
	draw_rectangle(
		menu_vars.start_x / menu_vars.text_scale + x, 
		menu_vars.start_y / menu_vars.text_scale + y, 
		menu_vars.end_x   / menu_vars.text_scale + x, 
		menu_vars.end_y   / menu_vars.text_scale + y, 
		false
	);
	
	draw_set_color(menu_vars.col_in);
	draw_rectangle(
		(menu_vars.start_x + menu_vars.border_thickness) / menu_vars.text_scale + x, 
		(menu_vars.start_y + menu_vars.border_thickness) / menu_vars.text_scale + y, 
		(menu_vars.end_x   - menu_vars.border_thickness) / menu_vars.text_scale + x, 
		(menu_vars.end_y   - menu_vars.border_thickness) / menu_vars.text_scale + y, 
		false
	);

	// Draws text
	draw_set_font(menu_vars.text_fnt);
	draw_set_color(menu_vars.text_col);
	if (bat_status.is_choosing_caster) {
		draw_text(
			menu_vars.text_start_x / menu_vars.text_scale + x, 
			menu_vars.text_start_y / menu_vars.text_scale + y, 
			"* Currently choosing entity..."
		);
	}
	else if (bat_status.is_choosing_move) {
		draw_text(
			menu_vars.text_start_x / menu_vars.text_scale + x, 
			menu_vars.text_start_y / menu_vars.text_scale + y, 
			"* Currently choosing moves..."
		);
		for (var i = 0; i < array_length(bat_status.loc_moves); i++) {
			move_words = string_split(bat_status.loc_moves[i], " ")
			
			// Turns the move name into a proper upper-cased string for display
			new_move = ""
			for(j = 0; j < array_length(move_words); j++){
				new_move += string_upper(string_copy(move_words[j], 0, 1)) + string_copy(move_words[j], 2, string_length(move_words[j])) + " "
			}
			
			draw_text(
				menu_vars.text_start_x / menu_vars.text_scale + x, 
				(menu_vars.text_start_y + (i + 1) * menu_vars.text_line_spacing + 1.5) / menu_vars.text_scale + y, 
				"     " + new_move
			);
		}
	}
	else if(bat_status.is_applying_move){
		draw_text(
			menu_vars.text_start_x / menu_vars.text_scale + x, 
			menu_vars.text_start_y / menu_vars.text_scale + y, 
			bat_status.move_curr_status
		);
	}

	surface_reset_target();

	// Create sprite from surface and store in surface_spr
	surface_spr = sprite_create_from_surface(surface, 0, 0, surf_w, surf_h, false, false, 0, 0);
}

if (!surface_is_dirty && sprite_exists(surface_spr)) {
	draw_sprite_ext(
		surface_spr,
		0,
		x,
		y,
		menu_vars.text_scale,
		menu_vars.text_scale,
		0,
		c_white,
		1
	);
}

if (bat_status.is_choosing_move) {
	draw_set_color(menu_vars.sel_col);
	draw_text_transformed(
		menu_vars.text_start_x + (menu_vars.sel_offs_x / 2) * (1 + sin(frames * menu_vars.sel_spd)) + menu_vars.sel_offs_init_x, 
		menu_vars.text_start_y + (bat_status.curr_index + 1) * menu_vars.text_line_spacing + 1.5, 
		menu_vars.sel_string,
		menu_vars.text_scale,
		menu_vars.text_scale,
		0
	);
	draw_set_color(menu_vars.text_col);
}
