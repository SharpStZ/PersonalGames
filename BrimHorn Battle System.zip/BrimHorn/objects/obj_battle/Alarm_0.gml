/// @description Initial start
BAT_GenerateAllExistingEntities()

BAT_SetInitValidChoicePointers()
BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, menu_ptr.slot, true)
