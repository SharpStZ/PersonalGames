slot_curr = menu_ptr.slot
slot_change = menu_ptr.slot	

party_curr = menu_ptr.party
party_change = menu_ptr.party	

// Is choosing who casts the move
if(bat_status.is_choosing_caster and !keyboard_check(vk_alt)){
	
	// Checks who performs the selection
	// Switches to maintain consistency across input code readability, even if some seem redundant here.
	switch menu_ptr.party {
		case "player":
			switch menu_ptr.slot {
				case "three":
					if(BAT_EntityInstanceExists("player", "leader")){
						slot_change = "leader"
						break;
					}
					if(BAT_EntityInstanceExists("player", "two")){
						slot_change = "two"
						break;
					}
				case "leader":
				case "two":
					if(BAT_EntityInstanceExists("player", "one"))
						slot_change = "one"
				break;
			}
		break;
		
		case "enemy":
			switch menu_ptr.slot {
				case "three":
					if(BAT_EntityInstanceExists("enemy", "leader")){
						slot_change = "leader"
						break;
					}
					if(BAT_EntityInstanceExists("enemy", "two")){
						slot_change = "two"
						break;
					}
				case "leader":
				case "two":
					if(BAT_EntityInstanceExists("enemy", "one"))
						slot_change = "one"
				break;
			}
		break;
		
		case "neutral":
			switch menu_ptr.slot {
				case "three":
					if(BAT_EntityInstanceExists("neutral", "one"))
						slot_change = "one"
					else if(BAT_EntityInstanceExists("neutral", "two"))
						slot_change = "two"
				break;
			}
		break;
	}
	
	if(slot_curr != slot_change){
		BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, slot_curr, false)
		BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, slot_change, true)
									
		menu_ptr.slot = slot_change
	}
}

// Is choosing a party
else if(bat_status.is_choosing_caster and keyboard_check(vk_alt)){
	
	// When switching parties from 
	if(array_contains(variable_struct_get(bat_status.aval_parties, bat_status.who_moves), "neutral") and menu_ptr.party != "neutral"){
		if(BAT_EntityInstanceExists("neutral", "three")){
			party_change = "neutral"
			slot_change = "three"
		}
		else if(BAT_EntityInstanceExists("neutral", "one")){
			party_change = "neutral"
			slot_change = "one"
		}
		else if(BAT_EntityInstanceExists("neutral", "two")){
			party_change = "neutral"
			slot_change = "two"
		}
	}
	
	if(party_curr != party_change){
		BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, menu_ptr.slot, false)
		BAT_ChangeSelectionStatusOfEntity(party_change, slot_change, true)
		
		menu_ptr.party = party_change
		menu_ptr.slot = slot_change
	}
}
	
	
	
// Is choosing move
else if(bat_status.is_choosing_move and bat_status.curr_index - 1 >= 0){
	bat_status.curr_index--
	menu_ptr.move = BAT_RetrieveEntityPointer(menu_ptr.party, menu_ptr.slot).ent.moves[bat_status.curr_index]
}



// Is choosing move entity slot
else if(bat_status.is_choosing_move_entities and !keyboard_check(vk_alt)){
	
	// Checks who performs the selection
	// Switches to maintain consistency across input code readability, even if some seem redundant here.
	switch menu_ptr.party {
		case "player":
			switch menu_ptr.slot {
				case "three":
					if(BAT_EntityInstanceExists("player", "leader")
						and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"player"], "leader")){
						slot_change = "leader"
						break;
					}
					if(BAT_EntityInstanceExists("player", "two")
						and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"player"], "two")){
						slot_change = "two"
						break;
					}
				case "leader":
				case "two":
					if(BAT_EntityInstanceExists("player", "one")
						and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"player"], "one"))
						slot_change = "one"
				break;
			}
		break;
		
		case "enemy":
			switch menu_ptr.slot {
				case "three":
					if(BAT_EntityInstanceExists("enemy", "leader")
						and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"enemy"], "leader")){
						slot_change = "leader"
						break;
					}
					if(BAT_EntityInstanceExists("enemy", "two")
						and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"enemy"], "two")){
						slot_change = "two"
						break;
					}
				case "leader":
				case "two":
					if(BAT_EntityInstanceExists("enemy", "one")
						and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"enemy"], "one"))
						slot_change = "one"
				break;
			}
		break;
		
		case "neutral":
			switch menu_ptr.slot {
				case "three":
					if(BAT_EntityInstanceExists("neutral", "one")
						and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"neutral"], "one"))
						slot_change = "one"
					else if(BAT_EntityInstanceExists("neutral", "two")
						and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"neutral"], "two"))
						slot_change = "two"
				break;
			}
		break;
	}
	
	if(slot_curr != slot_change){
		BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, slot_curr, false)
		BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, slot_change, true)
									
		menu_ptr.slot = slot_change
	}
}

// Is choosing move entity party
else if(bat_status.is_choosing_move_entities and keyboard_check(vk_alt)){
	
	// When switching parties from 
	if(array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).party, "neutral") and menu_ptr.party != "neutral"){
		if(BAT_EntityInstanceExists("neutral", "three")
			and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"neutral"], "three")){
			party_change = "neutral"
			slot_change = "three"
		}
		else if(BAT_EntityInstanceExists("neutral", "one")
			and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"neutral"], "one")){
			party_change = "neutral"
			slot_change = "one"
		}
		else if(BAT_EntityInstanceExists("neutral", "two")
			and array_contains(variable_struct_get(bat_status.choices, bat_status.curr_choosing.who).slot[?"neutral"], "two")){
			party_change = "neutral"
			slot_change = "two"
		}
	}
	
	if(party_curr != party_change){
		BAT_ChangeSelectionStatusOfEntity(menu_ptr.party, menu_ptr.slot, false)
		BAT_ChangeSelectionStatusOfEntity(party_change, slot_change, true)
		
		menu_ptr.party = party_change
		menu_ptr.slot = slot_change
	}
}