{
  "$GMNotes":"",
  "%Name":"Battle Move Syntax",
  "name":"Battle Move Syntax",
  "parent":{
    "name":"Notes",
    "path":"folders/Notes.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}